<?php
/**
 * i-doit
 *
 * OTRSC module class.
 *
 * @package     Modules
 * @subpackage  OTRSC
 * @author      Jakob Semere <jakob.semere@becon.de>
 * @version     1.5.1
 * @copyright   Becon GmbH
 * @since       i-doit 1.8.0
 */

return array(
	'LC__MODULE__OTRSC'			                    => 'OTRSC',
	'LC__CMDB__CATG__OTRSC'				            => 'OTRSC Tickets',
	'LC__MODULE__OTRSC_API'                         => 'OTRSC Management API',
    'LC__MODULE__OTRSC__CONFIGURE'                  => 'Konfiguration',
    'LC__MODULE__OTRSC__START_TEST'                 => 'Teste Verbindung',
    'LC__MODULE__OTRSC__AJAX_START'                 => 'Starte Test',
    'LC__MODULE__OTRSC__AJAX_FIN'                   => 'Test beendet',
    'LC__MODULE__OTRSC__CONFIG__SYSTEM'             => 'OTRS-System',
    'LC__MODULE__OTRSC__CONFIG__DOMAIN'             => 'Domain',
    'LC__MODULE__OTRSC__CONFIG__PATH'               => 'HTTP-Pfad zum OTRS-System',
    'LC__MODULE__OTRSC__CONFIG__USERNAME'           => 'Benutzername',
    'LC__MODULE__OTRSC__CONFIG__PASSWORD'           => 'Passwort',
    'LC__MODULE__OTRSC__CONFIG__TENANT'             => 'Webservice-Name',
    'LC__MODULE__OTRSC__AUTH_CONFIG'                => 'OTRSC-Konfiguration',
    'LC__MODULE__OTRSC__AUTH_GET_TICKETS'           => 'Tickets aus Ticketsystem holen',

);
