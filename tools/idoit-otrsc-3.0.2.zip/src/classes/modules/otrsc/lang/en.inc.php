<?php
/**
 * i-doit
 *
 * OTRSC module class.
 *
 * @package     Modules
 * @subpackage  OTRSC
 * @author      Jakob Semere <jakob.semere@becon.de>
 * @version     1.5.1
 * @copyright   Becon GmbH
 * @since       i-doit 1.8.0
 */

return array(
    'LC__MODULE__OTRSC'                             => 'OTRSC',
	'LC__CMDB__CATG__OTRSC'				            => 'OTRSC tickets',
    'LC__MODULE__OTRSC_API'                         => 'OTRSC management API',
    'LC__MODULE__OTRSC__CONFIGURE'                  => 'Configuration',
    'LC__MODULE__OTRSC__START_TEST'                 => 'Testing connection',
    'LC__MODULE__OTRSC__AJAX_START'                 => 'Start test',
    'LC__MODULE__OTRSC__AJAX_FIN'                   => 'Test finished',
    'LC__MODULE__OTRSC__CONFIG__SYSTEM'             => 'OTRS system',
    'LC__MODULE__OTRSC__CONFIG__DOMAIN'             => 'Domain',
    'LC__MODULE__OTRSC__CONFIG__PATH'               => 'HTTP path to OTRS system',
    'LC__MODULE__OTRSC__CONFIG__USERNAME'           => 'Username',
    'LC__MODULE__OTRSC__CONFIG__PASSWORD'           => 'Password',
    'LC__MODULE__OTRSC__CONFIG__TENANT'             => 'Webservice name',
    'LC__MODULE__OTRSC__AUTH_CONFIG'                => 'OTRSC configuration',
    'LC__MODULE__OTRSC__AUTH_GET_TICKETS'           => 'Get tickets from ticket system',

);
