<?php
/**
 * i-doit
 *
 * OTRSC module class.
 *
 * @package     Modules
 * @subpackage  OTRSC
 * @author      Jakob Semere <jakob.semere@becon.de>
 * @version     1.5.1
 * @copyright   Becon GmbH
 * @since       i-doit 1.8.0
 */

if (isys_module_manager::instance()->is_active('otrsc'))
{
	if (include_once('isys_module_otrsc_autoload.class.php'))
	{
		spl_autoload_register('isys_module_otrsc_autoload::init');
	} // if

	// Handle module specific language files.
	global $g_comp_session;

	if (file_exists(__DIR__ . DS . 'lang' . DS . $g_comp_session->get_language() . '.inc.php'))
	{
		$l_language = include_once (__DIR__ . DS . 'lang' . DS . $g_comp_session->get_language() . '.inc.php');

		if (is_array($l_language))
		{
			global $g_comp_template_language_manager;
			$g_comp_template_language_manager->append_lang($l_language);
		} // if
	} // if
    isys_component_signalcollection::get_instance()
        ->connect(
            'mod.cmdb.processMenuTreeLinks',
            [
                'isys_module_otrsc',
                'process_menu_tree_links'
            ]
        );

} // if

