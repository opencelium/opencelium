<?php
/**
 * i-doit
 *
 * OTRSC module class.
 *
 * @package     Modules
 * @subpackage  OTRSC
 * @author      Jakob Semere <jakob.semere@becon.de>
 * @version     1.5.1
 * @copyright   Becon GmbH
 * @since       i-doit 1.8.0
 */

class isys_module_otrsc_autoload extends isys_module_manager_autoload
{
        /**
         * Module specific autoloader.
         *
         * @param   string  $p_classname
         * @return  boolean
         * @throws  Exception
         */
        public static function init ($className)
        {
                $addOnPath = '/src/classes/modules/otrsc/';
                $classMap = [
                    'isys_ajax_handler_otrsc'                => 'handler/ajax/isys_ajax_handler_otrsc.class.php',
                    'isys_auth_otrsc'                        => 'auth/isys_auth_otrsc.class.php',
                ];

                if (isset($classMap[$className]) && parent::include_file($addOnPath . $classMap[$className])) {
                    isys_cache::keyvalue()->ns('autoload')->set($className, $addOnPath . $classMap[$className]);

                    return true;
                }

                return false;
        } // function
} // class
