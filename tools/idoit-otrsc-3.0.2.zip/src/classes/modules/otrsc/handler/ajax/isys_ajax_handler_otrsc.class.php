<?php
/**
 * i-doit
 *
 * Becon OTRSC Ajax handler
 *
 * @package     Handler/Ajax
 * @subpackage  otrsc
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_ajax_handler_otrsc extends isys_ajax_handler
{

    /**
     * Logger instance
     *
     * @var isys_log
     */
    private $logger;

    private $db;

    /**
     * isys_ajax_handler_otrsc constructor.
     *
     * @param array $get
     * @param array $post
     */
    public function __construct(array $get, array $post)
    {
        parent::__construct($get, $post);

        // Create logger
        $this->logger = isys_factory_log::get_instance('otrsc')
            ->set_destruct_flush(false)
            ->set_log_file(null);
    }

    public function init(){
        try {
            switch ($this->m_get['func']) {
                case 'checkConnection':
                    $post = array(
                        'ConfigItemID' => '1'
                    );

                    $tenant = rawurlencode($this->m_post['tenant']);

                    $response = $this->request($this->m_post['url']."/nph-genericinterface.pl/Webservice/".$tenant."/GetAllTickets/".$this->m_post['user']."/".$this->m_post['pass'], $post, '', 'POST');

                    $response = json_decode($response);

                    if( !$response ){
                        echo "Fehler! Prüfen Sie Ihre Konfiguration.";
                    }else{
                        echo "Verbindung erfolgreich!";
                    }
                break;
                case 'getTicketsForObject':

                    $conn = $this->getConnectorCredentials();

                    if($conn['isys_otrsc_domain'] && $conn['isys_otrsc_path'] && $conn['isys_otrsc_user'] && $conn['isys_otrsc_pass'] && $conn['isys_otrsc_tenant']){

                        $post = array(
                            'ConfigItemID' => $this->m_post['objID'],
                        );

                        $tenant = rawurlencode($conn['isys_otrsc_tenant']);

                        $response = $this->request($conn['isys_otrsc_domain'].$conn['isys_otrsc_path']."/nph-genericinterface.pl/Webservice/".$tenant."/GetAllTickets/".$conn['isys_otrsc_user']."/".$conn['isys_otrsc_pass'], $post, '', 'POST');
                        $response = json_decode($response);

                            if( !isset($response) || isset($response->Error) ){
                            echo '<div  style="position: relative;left: 20px;font-size: 12px;">Fehler! Prüfen Sie Ihre Konfiguration.</div>';
                        }
                        else{
                            $html = "<style>
                    .sortcol {
                        cursor: pointer;
                        padding-right: 20px;
                        background-repeat: no-repeat;
                        background-position: right center;
                    }
                    .sortasc {
                        background-color: #DDFFAC;
                        background-image: url(up.gif);
                    }
                    .sortdesc {
                        background-color: #B9DDFF;
                        background-image: url(down.gif);
                    }
                    </style>";


                            $html .= '<table class="sortable listing m10" cellpadding="0" cellspacing="0">
                                            <thead>
                                            <tr>
                                                    <th class="sortfirstdesc">T-Nummer</th>
                                                    <th>Subject</th>
                                                    <th>Queue</th>
                                                    <th>Besitzer</th>                                
                                                    <th>Status</th>
                                                    <th>Priorität</th>
                                                    <th class="date-de">Erstellt am</th>
                                            </tr>
                                            </thead>
                                            <tbody>';

                                    foreach ($response as $key => $value){
                                            $empty = "empty";
                                            $html .= "<tr>";
                                            $html .= "<td><a target='_blank' href ='".$conn['isys_otrsc_domain'].$conn['isys_otrsc_path']."/index.pl?Action=AgentTicketZoom;TicketID=".$response->$key->TicketID."'>".$response->$key->TicketNumber."</a></td>";
                                            $html .= "<td>".$response->$key->Title."</td>";
                                            $html .= "<td>".$response->$key->Queue."</td>";
                                            $html .= "<td>".$response->$key->Owner."</td>";                        
                                            $html .= "<td>".$response->$key->State."</td>";
                                            $html .= "<td>".$response->$key->Priority."</td>";
                                            $html .= "<td>".$response->$key->Created."</td>";
                                            $html .= "</tr>";
                                    }
                            $html .= '</tbody></table>';
                            if( empty($empty) ){
                                echo '<div  style="position: relative;left: 20px;font-size: 12px;">keine Tickets vorhanden</div>';
                            } else {
                                echo $html;
                            }
                        }
                    }

                break;
            }
        } catch (Exception $e) {
            echo "Error: ". $e->getMessage();
        }
        $this->_die();
    }

    private function request($url,$fields, $header,$post){
        //open connection
        $ch = curl_init();

        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json') );
        curl_setopt($ch,CURLOPT_URL, $url);

            curl_setopt($ch,CURLOPT_POST, 1);
            curl_setopt($ch,CURLOPT_POSTFIELDS, json_encode($fields));

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //execute post


        $result = curl_exec($ch);

        //close connection
        curl_close($ch);


        return $result;
    }

    private function getConnectorCredentials(){


        $sql = "SELECT isys_otrsc_domain,isys_otrsc_path,isys_otrsc_user,isys_otrsc_pass,isys_otrsc_tenant FROM isys_otrsc";

        $result = $this->m_database_component->query($sql);

        $data = $this->m_database_component->fetch_row_assoc( $result );

        return $data;
    }
}