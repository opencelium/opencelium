<?php
/**
 * i-doit
 *
 * OTRSC module class.
 *
 * @package     Modules
 * @subpackage  OTRSC
 * @author      Jakob Semere <jakob.semere@becon.de>
 * @version     2.0.0
 * @copyright   becon GmbH
 * @since       i-doit 1.8.0
 */

class isys_module_otrsc extends isys_module implements isys_module_interface, isys_module_authable
{
	// Define, if this module shall be displayed in the named menus.
	const DISPLAY_IN_MAIN_MENU   = true;
	const DISPLAY_IN_SYSTEM_MENU = false;

	/**
	 * Variable which holds the template component.
	 * @var  isys_component_template
	 */
	protected $m_tpl = null;

	/**
	 * Initializes the module.
	 *
	 * @param   isys_module_request& $p_req
	 * @return  isys_module_otrsc
	 * @author  Jakob Semere <jakob.semere@becon.de>
	 */
	public function init(isys_module_request &$p_req)
	{
		$this->m_db = $p_req->get_database();
		$this->m_tpl = $p_req->get_template()->assign('www_dir', self::get_tpl_www_dir());
        $this->m_tpl->appendJavascript(self::get_assets_www_dir() . 'js/becon_otrsc.js');
		return $this;
	} // function


	/**
	 * Static method for retrieving the path, to the modules templates.
	 *
	 * @static
	 * @return  string
	 * @author  Jakob Semere <jakob.semere@becon.de>
	 */
	public static function get_tpl_dir ()
	{
		return __DIR__ . DS . 'templates' . DS;
	} // function

	/**
	 * Static method for retrieving the path, to the modules templates.
	 *
	 * @static
	 * @global  array $g_dirs
	 * @return  string
	 * @author  Jakob Semere <jakob.semere@becon.de>
	 */
	public static function get_tpl_www_dir ()
	{
		global $g_config;

		return $g_config['www_dir'] . 'src/classes/modules/otrsc/templates/';
	} // function


    /**
     * Static method for retrieving the path to the modules assets
     *
     * @static
     * @global  array $g_dirs
     * @return  string
     * @author  Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
     */
    public static function get_assets_www_dir(){
        global $g_config;

        return $g_config['www_dir'] . 'src/classes/modules/otrsc/assets/';   
    }

    /**
     * Get related auth class for module
     *
     * @static
     * @return isys_auth
     */
    public static function get_auth()
    {
        return isys_auth_otrsc::instance();
    }


	/**
	 * This method builds the tree for the menu.
	 *
	 * @param   isys_component_tree  $p_tree
	 * @param   boolean              $p_system_module
	 * @param   integer              $p_parent
	 * @author  Jakob Semere <jakob.semere@becon.de>
	 * @see     isys_module_cmdb->build_tree();
	 */
	public function build_tree(isys_component_tree $p_tree, $p_system_module = true, $p_parent = null)
	{
		global $g_dirs;
        $auth = self::get_auth();

			$l_root = $p_tree->add_node(
				C__MODULE__OTRSC,
				$p_parent,
				_L('LC__MODULE__OTRSC_API'),
                "",
                "",
                self::get_assets_www_dir() . 'images/otrsc_logo.png',
			);

            $p_tree->add_node(
                C__MODULE__OTRSC . 3,
                $l_root,
                _L('LC__MODULE__OTRSC__CONFIGURE'),
                isys_helper_link::create_url(array(
                        C__GET__MODULE_ID =>  C__MODULE__OTRSC,
                        C__GET__SETTINGS_PAGE => 'config',
                        C__GET__TREE_NODE => C__MODULE__OTRSC . 3
                )),
                '',
                $g_dirs['images'] . 'axialis/basic/gear.svg',
                (int) ($_GET[C__GET__TREE_NODE] == C__MODULE__OTRSC. 3),
                '',
                '',
                $auth->is_allowed_to(isys_auth::EDIT, 'otrsc_config')
            );
	} // function


	/**
	 * Start method.
	 */
	public function start()
	{
		global $g_active_modreq;
		
		// Build the module tree, but only if we are not in the system-module.
		if ($_GET[C__GET__MODULE_ID] != C__MODULE__SYSTEM)
		{
			$l_tree = $g_active_modreq->get_menutree();
			$this->build_tree($l_tree, false, -1);
			
			$this->m_tpl->assign("menu_tree", $l_tree->process($_GET[C__GET__TREE_NODE]));
		} // if

		$this->m_tpl->assign('tpl_www_dir', self::get_tpl_www_dir());

		switch ($_GET[C__GET__SETTINGS_PAGE])
		{	
			case "config":
				$l_id = $_POST['id'][0] ? : $_GET['id'];
                                $this->config($l_id);
                                break;
			default:
				$l_id = $_POST['id'][0] ? : $_GET['id'];
				$this->config($l_id);
				break;
		} // switch
	} // function

    /**
     * Method for adding links to the "sticky" category bar.
     *
     * @param  isys_component_template $p_tpl
     * @param  string                  $p_tpl_var
     * @param  integer                 $p_obj_id
     * @param  integer                 $p_obj_type_id
     */
    public static function process_menu_tree_links($p_tpl, $p_tpl_var, $p_obj_id, $p_obj_type_id)
    {
        global $g_config, $g_dirs;

        $auth = self::get_auth();

        if($auth->is_allowed_to(isys_auth::EXECUTE, 'otrsc_get_tickets')){

    		$divBottom = 'contentBottom';

            //$session = isys_application::instance()->container->get('session');

            //$tenant = $session->get_mandator_name();

            $l_dao = new isys_component_dao(isys_application::instance()->container->get('database'));

            $l_ret = $l_dao->retrieve("SELECT isys_otrsc_system FROM isys_otrsc");
            $otrs_system = $l_ret->get_row_value('isys_otrsc_system');

            if(!empty($otrs_system)){
                $l_link_data = [
                    'title' => _L('LC__CMDB__CATG__OTRSC'),
                    'icon'  => self::get_assets_www_dir() . 'images/'.$otrs_system.'.png',
                    'link'  => "javascript:get_otrs_tickets('".$p_obj_id."')",
                ];

                $p_tpl->append($p_tpl_var, ['otrsc' => $l_link_data], true);

            }
        }


    } // function

    /**
     * Method for processing the search logbook tags page.
     *
     * @author  Jakob Semere <jakob.semere@becon.de>
     */
    protected function config ($p_id)
    {
        global $index_includes;
	    global $g_comp_database;
    
		$l_dao = new isys_component_dao($this->m_db);
		
		if( $_POST['user'] || $_POST['pass'] || $_POST['domain']|| $_POST['path']|| $_POST['tenant'] ){
			$l_ret = $l_dao->retrieve("DELETE FROM isys_otrsc");

            $sql = "INSERT INTO isys_otrsc (isys_otrsc_system,isys_otrsc_user,isys_otrsc_pass,isys_otrsc_domain,isys_otrsc_path,isys_otrsc_tenant) 
            VALUES (".
                $l_dao->convert_sql_text($_POST['system']).",".
                $l_dao->convert_sql_text($_POST['user']).",".
                $l_dao->convert_sql_text($_POST['pass']).",".
                $l_dao->convert_sql_text($_POST['domain']).",".
                $l_dao->convert_sql_text($_POST['path']).",".
                $l_dao->convert_sql_text($_POST['tenant']).
            ")";
			$l_ret = $l_dao->retrieve($sql);
		}
	
		$l_ret = $l_dao->retrieve("SELECT isys_otrsc_system,isys_otrsc_domain,isys_otrsc_path,isys_otrsc_user,isys_otrsc_pass,isys_otrsc_tenant FROM isys_otrsc");
        $l_row = $l_ret->get_row(IDOIT_C__DAO_RESULT_TYPE_ROW);     

        $system = $l_row[0] ?? '';
        $domain = $l_row[1] ?? '';
        $path = $l_row[2] ?? '/otrs';
        $user = $l_row[3] ?? '';
        $pass = $l_row[4] ?? '';
        $tenant = $l_row[5] ?? '';

		
        $l_navbar = isys_component_template_navbar::getInstance();
        switch ($_POST[C__GET__NAVMODE])
            {
                case C__NAVMODE__EDIT:
                    $l_navbar->set_active(true, C__NAVBAR_BUTTON__SAVE)
                             ->set_active(true, C__NAVBAR_BUTTON__CANCEL);
                    break;
                default:
	    $visible = "disabled=disabled";
                $l_navbar->set_active(true, C__NAVBAR_BUTTON__EDIT)
                         ->set_visible(true, C__NAVBAR_BUTTON__EDIT);
                break;
        }

        $ajax_url = isys_helper_link::create_url([C__GET__AJAX_CALL => 'otrsc', C__GET__AJAX => 1,'func' => 'checkConnection']);
	
		$this->m_tpl
            ->activate_editmode()
            ->assign('headline', _L('LC__MODULE__OTRSC__CONFIGURE'))
			->assign('visible', $visible)
            ->assign('system', $system)
            ->assign('domain', $domain)
            ->assign('path', $path)
			->assign('user', $user)
			->assign('pass', $pass)
			->assign('tenant', $tenant)
			->assign('start_check',_L('LC__MODULE__OTRSC__START_TEST'))
			->assign('start_ajax', _L('LC__MODULE__OTRSC__AJAX_START'))
            ->assign('fin_ajax', _L('LC__MODULE__OTRSC__AJAX_FIN'))
            //->assign('ajax_url', "script/otrsc/sync.php")
            ->assign('ajax_url', $ajax_url)
            ->smarty_tom_add_rules('tom.content.bottom.content', $l_rules);

        $index_includes['contentbottomcontent'] = self::get_tpl_dir() . 'config.tpl';
    } // function

} // class