<?php
use idoit\Module\Becon_Oc\Model\Config;

/**
 * i-doit
 *
 * Becon_OC Ajax handler
 *
 * @package     Handler/Ajax
 * @subpackage  becon_OpenCelium
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_ajax_handler_becon_oc extends isys_ajax_handler
{

    /**
     * Logger instance
     *
     * @var isys_log
     */
    private $logger;

    /**
     * isys_ajax_handler_cmk2_command constructor.
     *
     * @param array $get
     * @param array $post
     */
    public function __construct(array $get, array $post)
    {
        parent::__construct($get, $post);

        // Create logger
        $this->logger = isys_factory_log::get_instance('becon_oc')
            ->set_destruct_flush(false)
            ->set_log_file(null);
    }

    public function init()
    {
        // We set the header information because we don't accept anything than JSON.
        header('Content-Type: application/json');

        $ajaxReturn = [
            'success' => true,
            'message' => null
        ];

        try {
            switch ($this->m_get['func']) {
                case 'callOcWebhook':
                    global $g_absdir;

                    // Set expiration header to 0
                    isys_core::expire(0);

                    // Check whether idoitcmk command is configured
                    $url_configured = false;
                    
                    $url = $this->m_get['url'];

                    $configModel = new Config(isys_application::instance()->container->get('database'));
                    $configs = $configModel->getConfigs()->__as_array();

                    foreach($configs as $conf){
                        $hooks = json_decode($conf['hooks'],true);
                        foreach($hooks as $hook){
                            if($hook['url'] == $url){
                                $url_configured = true;
                                break 2;
                            }
                        }
                    }
                    if($url_configured){

                        $objID = $this->m_get['objID'];
                        $catgID = $this->m_get['catgID'];
                        $cateID = $this->m_get['cateID'];
                        $url = isys_module_becon_oc::replace_url_placeholders($url,$objID,$catgID,$cateID);
                        $headers = get_headers($url);

                        if($headers === false){
                            $ajaxReturn['success'] = false;
                            $ajaxReturn['message'] = $url . ': '.isys_application::instance()->container->get('language')
                            ->get('LC__MODULE__BECON_OC__URL_NOT_AVAILABLE');
                        } else {
                            $reponse_code = 0;
                            foreach( $headers as $v ){
                                $t = explode( ':', $v, 2 );
                                if(! isset( $t[1] ) ){
                                    if( preg_match( "#HTTP/[0-9\.]+\s+([0-9]+)#",$v, $out ) )
                                        $reponse_code = intval($out[1]);
                                }
                            }
                            if($reponse_code == 200){
                                $ajaxReturn['success'] = true;
                                $ajaxReturn['message'] = 'Calling webhook: ' . $url;
                            } else {
                                $ajaxReturn['success'] = false;
                                $ajaxReturn['message'] = $url . ': '.isys_application::instance()->container->get('language')
                                    ->get('LC__MODULE__BECON_OC__URL_NOT_OK'). ' '.$reponse_code;
                            }
                        }
                    } else {
                        // Command was not found
                        $ajaxReturn['success'] = false;
                        $ajaxReturn['message'] = $url . ': '.isys_application::instance()->container->get('language')
                            ->get('LC__MODULE__BECON_OC__URL_NOT_CONFIGURED');

                    }

            }
        } catch (Exception $e) {
            $ajaxReturn['success'] = false;
            $ajaxReturn['message'] = $e->getMessage();
        }

        echo isys_format_json::encode($ajaxReturn);

        $this->_die();
    }

}
