<?php
/**
 * i-doit
 *
 * Module initializer
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */

if (isys_module_manager::instance()->is_active('becon_oc')) {
    require_once __DIR__ . '/isys_module_becon_oc_autoload.class.php';

    spl_autoload_register('isys_module_becon_oc_autoload::init');

    \idoit\Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Becon_Oc', __DIR__ . '/src/');
}
