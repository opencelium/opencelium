<?php
/**
 * i-doit
 *
 * "becon_OC" Module language file.
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */

return [
    'LC__MODULE__BECON_OC'                                          => 'OpenCelium',
    'LC__MODULE__BECON_OC__CONFIGURATION'                           => 'Webhook-Konfiguration',
    'LC__MODULE__BECON_OC__CALL_HOOK'                               => 'Webhooks aufrufen',
    'LC__MODULE__BECON_OC__CONFIG__HEADLINE'                        => 'OpenCelium Webhook-Konfiguration',
    'LC__MODULE__BECON_OC__CONFIG__DESCRIPTION'                     => 'Bitte geben Sie an, bei welchen Objekttypen und/oder Kategorien die Webhooks angezeigt werden sollen:',
    'LC__MODULE__BECON_OC__CONFIG__HOOK_PLACEHOLDER'                => 'Folgende Platzhalter können verwendet werden:',
    'LC__MODULE__BECON_OC__CONFIG_SAVE_SUCCESS'                     => 'Konfiguration erfolgreich gespeichert.',
    'LC__MODULE__BECON_OC__CONFIG_SAVE_ERROR'                       => 'Konfiguration konnte nicht gespeichert werden.',
    'LC__MODULE__BECON_OC__CONFIG_HOOK_NAME'                        => 'Name',
    'LC__MODULE__BECON_OC__CONFIG_HOOK_URL'                         => 'URL',
    'LC__MODULE__BECON_OC__CONFIG_ACTION'                           => 'Aktion',
    'LC__MODULE__BECON_OC__URL_NOT_CONFIGURED'                      => 'Webhook-URL ist nicht konfiguriert',
    'LC__MODULE__BECON_OC__URL_NOT_AVAILABLE'                       => 'Webhook-URL kann nicht aufgerufen werden. Eventuell ist der Server nicht erreichbar oder die DNS-Auflösung ist fehlgeschlagen.',
    'LC__MODULE__BECON_OC__URL_NOT_OK'                              => 'Server antwortet mit Code',
    'LC__MODULE__BECON_OC__NO_CONFIGURATION_SELECTED'               => 'Keine Webhook-Konfiguration ausgewählt.',
    'LC__MODULE__BECON_OC__HOOKS_DEFINED'                           => 'Webhooks definiert',
    'LC__MODULE__BECON_OC__CONFIG_ADD_HOOK'                         => 'Neuer Webhook',
    'LC__MODULE__BECON_OC__OBJECT_TYPES'                            => 'Objekttypen',
    'LC__MODULE__BECON_OC__CATEGORIES'                              => 'Kategorien',
    'LC__MODULE__BECON_OC__HOOKS'                                   => 'Webhooks',
    'LC__MODULE__BECON_OC__ALL_OBJECTTYPES'                         => 'Alle',
    'LC__MODULE__BECON_OC__CONFIG__IPV4'                            => 'IPv4-Adresse des aktuellen Hostadressen-Eintrags. Wenn man nicht in der Hostadressen-Einzelansicht ist, wird die primäre IP-Adresse benutzt.',
    'LC__MODULE__BECON_OC__CONFIG__HOSTNAME'                        => 'Hostname des aktuell besuchten Hostadressen-Eintrags. Wenn man nicht in der Hostadressen-Einzelansicht ist, wird der Hostname des primären Eintrags benutzt.',
    'LC__MODULE__BECON_OC__CONFIG__OBJID'                           => 'Objekt ID des aktuellen Objektes.',
    'LC__MODULE__BECON_OC__CONFIG__CATGID'                          => 'Kategorie ID der aktuellen globalen Kategorie.',
    'LC__MODULE__BECON_OC__CONFIG__CATEID'                          => 'ID des aktuellen Kategorieeintrags (nur bei Multivalue-Kategorien)',

];
