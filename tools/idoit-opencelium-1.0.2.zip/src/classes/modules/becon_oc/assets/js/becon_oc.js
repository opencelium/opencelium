window.callOcWebhook = function callOcWebhook(commandLinkElement, webHook, objId, catgId, cateId) {
    var $overlay             = $('new_overlay_becon_oc')
    var $clickedElementImage = $(commandLinkElement).down('img');
    var currentImageSource   = $clickedElementImage.readAttribute('src');
    
    $clickedElementImage.writeAttribute('src', 'images/ajax-loading.gif');

    // Disable command buttons
    $overlay.select('a').invoke('addClassName', 'non-clickable');

        var params = {
            ajax:        1,
            call:        'becon_oc',
            func:        'callOcWebhook',
            url:         webHook,
            objID:       objId,
            catgID:      catgId,
            cateID:      cateId
        };
        new Ajax.Request('?' + Object.toQueryString(params), {
        onSuccess: function (response) {
            // Parse JSON
            response = JSON.parse(response.responseText);

            // Enable command buttons
            $overlay.select('a').invoke('removeClassName', 'non-clickable');

            // Restore image src again
            $clickedElementImage.writeAttribute('src', currentImageSource);

            if (response.success) {
                idoit.Notify.success(response.message);
            } else {
                idoit.Notify.error(response.message);
            }
        }
    });
}
