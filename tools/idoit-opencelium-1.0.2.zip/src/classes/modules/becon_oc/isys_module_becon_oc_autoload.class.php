<?php

/**
 * i-doit
 *
 * Class autoloader.
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_module_becon_oc_autoload extends isys_module_manager_autoload
{
    /**
     * Module specific autoloader.
     *
     * @param   string $className
     *
     * @return  boolean
     */
    public static function init($className)
    {
        $addOnPath = '/src/classes/modules/becon_oc/';
        $classMap = [
            'isys_auth_becon_oc'                        => 'auth/isys_auth_becon_oc.class.php',
            'isys_becon_oc_dao'                         => 'dao/isys_becon_oc_dao.class.php',
            'isys_ajax_handler_becon_oc'                => 'handler/ajax/isys_ajax_handler_becon_oc.class.php',
        ];

        if (isset($classMap[$className]) && parent::include_file($addOnPath . $classMap[$className])) {
            isys_cache::keyvalue()->ns('autoload')->set($className, $addOnPath . $classMap[$className]);

            return true;
        }

        return false;
    }
}
