<?php
use idoit\AddOn\ActivatableInterface;
use idoit\AddOn\InstallableInterface;
use idoit\Module\Becon_Oc\SettingPage\OcConfiguration\OcConfiguration;
use idoit\Module\Becon_Oc\SettingPage\SettingPageInterface;
use idoit\Module\Becon_Oc\Model\Config;


/**
 * i-doit
 *
 * becon_OC module class.
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_module_becon_oc extends isys_module implements isys_module_interface, isys_module_authable
{
    // Define, if this module shall be displayed in the named menus.
    const DISPLAY_IN_MAIN_MENU   = true;
    const DISPLAY_IN_SYSTEM_MENU = false;

    /**
     * Variable which holds the becon_oc DAO class.
     *
     * @var  isys_becon_oc_dao
     */
    protected $m_dao;

    /**
     * Variable which holds the database component.
     *
     * @var  isys_component_database
     */
    protected $m_db;

    /**
     * Variable which holds the template component.
     *
     * @var  isys_component_template
     */
    protected $m_tpl;


    public static function get_assets_www_dir(){
        global $g_config;

        return $g_config['www_dir'] . 'src/classes/modules/becon_oc/assets/';   
    }

    /**
     * Static method for retrieving the path, to the modules templates.
     *
     * @static
     * @return  string
     */
    public static function get_tpl_dir()
    {
        return __DIR__ . '/templates/';
    }

    /**
     * Get related auth class for module
     *
     * @static
     * @return isys_auth
     */
    public static function get_auth()
    {
        return isys_auth_becon_oc::instance();
    }

    /**
     * Initializes the module.
     *
     * @param   isys_module_request & $p_req
     *
     * @return  isys_module_becon_oc
     */
    public function init(isys_module_request $p_req)
    {
        $this->m_db = $p_req->get_database();
        $this->m_tpl = $p_req->get_template();
        $this->m_tpl->appendJavascript(self::get_assets_www_dir() . 'js/becon_oc.js');

        //$auth = self::get_auth();
        //$is_allowed = $auth->is_allowed_to(isys_auth::EXECUTE, 'becon_oc_call');
        //if($is_allowed){
        $this->addButton();
        //}
        
        return $this;
    }

    /**
     * This method builds the tree for the menu.
     *
     * @param   isys_component_tree $p_tree
     * @param   boolean             $p_system_module
     * @param   integer             $p_parent
     *
     * @author  Leonard Fischer <lfischer@i-doit.com>
     * @see     isys_module_cmdb->build_tree();
     */
    public function build_tree(isys_component_tree $p_tree, $p_system_module = true, $p_parent = null)
    {

        $imagesBase = self::get_assets_www_dir() . 'images/';
        $auth = self::get_auth();

        // Check whether system menu mode is active
        if (!$p_system_module) {

            $rootNode = $p_tree->add_node(
                C__MODULE__BECON_OC.'001', 
                $p_parent, 
                $this->language->get('LC__MODULE__BECON_OC'), 
                '',
                '',
                $imagesBase.'opencelium_16x16.png'
            );


            $p_tree->add_node(
                C__MODULE__BECON_OC . '002',
                $rootNode,
                $this->language->get('LC__MODULE__BECON_OC__CONFIGURATION'),
                isys_helper_link::create_url([
                    C__GET__MODULE_ID     => C__MODULE__BECON_OC,
                    C__GET__SETTINGS_PAGE => 'oc_config',
                    C__GET__TREE_NODE     => C__MODULE__BECON_OC . '002'
                ]),
                '',
                'images/icons/silk/tag_blue_edit.png',
                (empty($_GET[C__GET__SETTINGS_PAGE]) || $_GET[C__GET__SETTINGS_PAGE] == 'oc_config'),
                '',
                '',
                $auth->is_allowed_to(isys_auth::EXECUTE, 'becon_oc_config')
            );
        }
    }

    /**
     * Start method.
     */
    public function start()
    {
        //$this->m_dao = new isys_becon_oc_dao($this->m_db);
        $defaultPage = 'oc_config';

        // Build the module tree, but only if we are not in the system-module.
        if ($_GET[C__GET__MODULE_ID] != C__MODULE__SYSTEM) {
            $l_tree = isys_component_tree::factory();

            $this->build_tree($l_tree, false, -1);

            $this->m_tpl->assign('menu_tree', $l_tree->process($_GET[C__GET__TREE_NODE]));

            $defaultPage = 'oc_config';
        }

        $page = $_GET[C__GET__SETTINGS_PAGE] ?: $defaultPage;

        $pageList = [
            'oc_config'   => OcConfiguration::class,
        ];

        if (!isset($pageList[$page])) {
            $page = $defaultPage;
        }

        $settingPage = new $pageList[$page]($this->m_tpl, $this->m_db, $this->language);
        $settingPage->renderPage((int)($_POST[C__GET__NAVMODE] ?: $_GET[C__GET__NAVMODE]));

    }


    /**
     * Checks if a add-on is installed.
     *
     * @return int|bool
     */
    public static function isInstalled()
    {
        return isys_module_manager::instance()->is_installed('becon_oc');
    }


    public static function replace_url_placeholders($url,$objID,$catgID,$catsID,$cateID){
        $db = isys_application::instance()->container->get('database');
        $l_replace_pairs = [
            '%ipv4%' => [],
            '%hostname%' => [],
            '%fqdn%' => [],
            '%objid%' => [],
            '%objtitle%' => [],
            '%catgid%' => '',
            '%catsid%' => '',
            '%cateid%' => [],
        ];
        $objIds = [];
        $dataIds = [];
        if(!empty($objID)){
            $objIds = explode(";",$objID);
        }
        if(!empty($cateID)){
            $dataIds = explode(",",$cateID);
        }
        foreach($objIds as $id){
            list($objId,$dataId) = explode(",",$id);
            $l_dao_ip = isys_cmdb_dao_category_g_ip::instance($db);
            $l_replace_pairs['%objid%'][] = $objId;
            $l_replace_pairs['%objtitle%'][] = urlencode($l_dao_ip->obj_get_title_by_id_as_string($objId));
            if(!empty($catgID)){
                $l_replace_pairs['%catgid%'] = $catgID;
                if(!empty($cateID)){
                    $l_replace_pairs['%cateid%'] = $dataIds;
                }
            } elseif(!empty($catsID)){
                $l_replace_pairs['%catsid%'] = $catsID;
                if($catsID == C__CATS__NET_IP_ADDRESSES && !empty($dataId)){
                    $l_replace_pairs['%cateid%'][] = $dataId;
                } elseif(!empty($cateID) && count($objIds) == 1){
                    $l_replace_pairs['%cateid%'] = $dataIds;
                }
            }
            if($catgID == C__CATG__IP && !empty($dataIds)){
                foreach($dataIds as $entryId){
                    $data = $l_dao_ip->get_data_as_array($entryId,$objId);
                    $l_replace_pairs['%ipv4%'][] = urlencode($data[0]['isys_cats_net_ip_addresses_list__title']);
                    $l_replace_pairs['%hostname%'][] = urlencode($data[0]['isys_catg_ip_list__hostname']);
                    $fqdn = $data[0]['isys_catg_ip_list__hostname'];
                    if(!empty($fqdn) && !empty($data[0]['isys_catg_ip_list__domain'])){
                        $fqdn .= ".".$data[0]['isys_catg_ip_list__domain'];
                    }
                    $l_replace_pairs['%fqdn%'][] = urlencode($fqdn);
                }
            } elseif($catsID == C__CATS__NET_IP_ADDRESSES && !empty($dataId)){
                $data = $l_dao_ip->get_data_as_array($dataId,$objId);
                $l_replace_pairs['%ipv4%'][] = urlencode($data[0]['isys_cats_net_ip_addresses_list__title']);
                $l_replace_pairs['%hostname%'][] = urlencode($data[0]['isys_catg_ip_list__hostname']);
                $fqdn = $data[0]['isys_catg_ip_list__hostname'];
                if(!empty($fqdn) && !empty($data[0]['isys_catg_ip_list__domain'])){
                    $fqdn .= ".".$data[0]['isys_catg_ip_list__domain'];
                }
                $l_replace_pairs['%fqdn%'][] = urlencode($fqdn);
            } else {
                $l_primary_ip_data = $l_dao_ip->get_primary_ip($objId)->get_row();
                $l_replace_pairs['%ipv4%'][] = urlencode($l_primary_ip_data['isys_cats_net_ip_addresses_list__title']);
                $l_replace_pairs['%hostname%'][] = urlencode($l_primary_ip_data['isys_catg_ip_list__hostname']);
                $fqdn = $l_primary_ip_data['isys_catg_ip_list__hostname'];
                if(!empty($fqdn) && !empty($l_primary_ip_data['isys_catg_ip_list__domain'])){
                    $fqdn .= ".".$l_primary_ip_data['isys_catg_ip_list__domain'];
                }
                $l_replace_pairs['%fqdn%'][] = urlencode($fqdn);
            }
        }
        foreach($l_replace_pairs as $key => &$targetString){
            if(is_array($targetString)){
                if(count($targetString) == 0){
                    $targetString = "[]";
                } else {
                    $targetString = "['".implode("','",$targetString)."']";
                }
            } else {
                if($key != '%catgid%' && $key != '%catsid%'){
                    if(empty($targetString)){
                        $targetString = "[]";
                    } else {
                        $targetString = "['".$targetString."']";
                    }
                }
            }
        }
        return strtr($url, $l_replace_pairs);
    }

    /**
     * Adds OpenCelium Button, if configured
     *
     * @return int|bool
     */
    public function addButton()
    {
        $imagesBase = self::get_assets_www_dir() . 'images/';
        $db = isys_application::instance()->container->get('database');
        $dao = isys_cmdb_dao::instance($db);
        $configModel = new Config($db);
        $configs = $configModel->getConfigs()->__as_array();
        $dropdownButtons = [];

        $objTypeOnly = [];
        $category_g_only = [];
        $category_s_only = [];
        $objTypeAndCategoryG = [];
        $objTypeAndCategoryS = [];

        foreach($configs as $conf){
            $objectTypes = [];
            if(!empty($conf['object_types'])) {
                $objectTypes =  explode(",",$conf['object_types']);
            }
            $categories = [];
            if(!empty($conf['categories'])) {
                $categories =  explode(",",$conf['categories']);
            }
            $categories_s = [];
            if(!empty($conf['categories_s'])) {
                $categories_s =  explode(",",$conf['categories_s']);
            }

            if(!empty($objectTypes) && empty($categories) && empty($categories_s)){
                foreach($objectTypes as $objType){
                    if(empty($objTypeOnly[$objType])){
                        $objTypeOnly[$objType] = [];
                    }
                    $hooks = json_decode($conf['hooks'],true);
                    array_push($objTypeOnly[$objType], ...$hooks);
                }
            } elseif(empty($objectTypes) && !empty($categories)){
                foreach($categories as $catg){
                    if(empty($category_g_only[$catg])){
                        $category_g_only[$catg] = [];
                    }
                    $hooks = json_decode($conf['hooks'],true);
                    array_push($category_g_only[$catg],...$hooks);
                }
            } elseif(empty($objectTypes) && !empty($categories_s)){
                foreach($categories_s as $cats){
                    if(empty($category_s_only[$cats])){
                        $category_s_only[$cats] = [];
                    }
                    $hooks = json_decode($conf['hooks'],true);
                    array_push($category_s_only[$cats],...$hooks);
                }
            } elseif(!empty($objectTypes) && !empty($categories)){
                foreach($categories as $catg){
                    if(empty($objTypeAndCategoryG[$catg])){
                        $objTypeAndCategoryG[$catg] = [];
                    }
                    foreach($objectTypes as $objType){
                        if(empty($objTypeAndCategoryG[$catg][$objType])){
                            $objTypeAndCategoryG[$catg][$objType] = [];
                        }
                        $hooks = json_decode($conf['hooks'],true);    
                        array_push($objTypeAndCategoryG[$catg][$objType],...$hooks);
                    }
                }
            } elseif(!empty($objectTypes) && !empty($categories_s)){
                foreach($categories_s as $cats){
                    if(empty($objTypeAndCategoryS[$cats])){
                        $objTypeAndCategoryS[$cats] = [];
                    }
                    foreach($objectTypes as $objType){
                        if(empty($objTypeAndCategoryS[$cats][$objType])){
                            $objTypeAndCategoryS[$cats][$objType] = [];
                        }
                        $hooks = json_decode($conf['hooks'],true);    
                        array_push($objTypeAndCategoryS[$cats][$objType],...$hooks);
                    }
                }
            }
        }

        if(!empty($_GET['objTypeID']) && !empty($objTypeOnly[$_GET['objTypeID']])){
            foreach ($objTypeOnly[$_GET['objTypeID']] as $hook) {
                $dropdownButtons[] = [
                    'title'   => $hook['name'],
                    'icon'    => 'icons/silk/link_go.png',
                    'href'    => 'javascript:;',
                    'url'     => $hook['url'],
                ];
            }
        }
        if(!empty($_GET['catgID']) && !empty($_GET['objID']) && !empty($category_g_only[$_GET['catgID']])){
            foreach ($category_g_only[$_GET['catgID']] as $hook) {
                $dropdownButtons[] = [
                    'title'   => $hook['name'],
                    'icon'    => 'icons/silk/link_go.png',
                    'href'    => 'javascript:;',
                    'url'     => $hook['url'],
                ];
            }
        }
        if(!empty($_GET['catsID']) && !empty($_GET['objID']) && !empty($category_s_only[$_GET['catsID']])){
            foreach ($category_s_only[$_GET['catsID']] as $hook) {
                $dropdownButtons[] = [
                    'title'   => $hook['name'],
                    'icon'    => 'icons/silk/link_go.png',
                    'href'    => 'javascript:;',
                    'url'     => $hook['url'],
                ];
            }
        }
        if(!empty($_GET['catgID']) && !empty($_GET['objID']) && !empty($objTypeAndCategoryG[$_GET['catgID']])){
            $obj_data = $dao->get_object_by_id($_GET['objID'])->get_row();
            if(!empty($objTypeAndCategoryG[$_GET['catgID']][$obj_data['isys_obj_type__id']])){
                foreach ($objTypeAndCategoryG[$_GET['catgID']][$obj_data['isys_obj_type__id']] as $hook) {
                    $dropdownButtons[] = [
                        'title'   => $hook['name'],
                        'icon'    => 'icons/silk/link_go.png',
                        'href'    => 'javascript:;',
                        'url'     => $hook['url'],
                    ];
                }
            }
        }
        if(!empty($_GET['catsID']) && !empty($_GET['objID']) && !empty($objTypeAndCategoryS[$_GET['catsID']])){
            $obj_data = $dao->get_object_by_id($_GET['objID'])->get_row();
            if(!empty($objTypeAndCategoryS[$_GET['catsID']][$obj_data['isys_obj_type__id']])){
                foreach ($objTypeAndCategoryS[$_GET['catsID']][$obj_data['isys_obj_type__id']] as $hook) {
                    $dropdownButtons[] = [
                        'title'   => $hook['name'],
                        'icon'    => 'icons/silk/link_go.png',
                        'href'    => 'javascript:;',
                        'url'     => $hook['url'],
                    ];
                }
            }
        }
        $objID = (int) $_GET['objID'] ?? 0;
        $catgID = (int) $_GET['catgID'] ?? 0;
        $catsID = (int) $_GET['catsID'] ?? 0;
        $cateID = 0;
        if(!empty($_GET['cateID'])){
            $cateID = (int) $_GET['cateID'];
        } elseif(!empty($_POST['id'][0]) && count($_POST['id']) == 1){
            $cateID = (int) $_POST['id'][0];
        }

        foreach($dropdownButtons as $key=>$elem){
            $dropdownButtons[$key]['onclick'] = "window.callOcWebhook(this,'{$elem['url']}',$objID,$catgID,$catsID,$cateID)";
            unset($dropdownButtons[$key]['url']);
        }

        if(!empty($dropdownButtons)){
            $navbarButtonOptions = [
                'active'     => true,
                'visible'    => true,
                'navmode'    => 'becon_oc',
                'icon'       => self::get_assets_www_dir().'images/opencelium_16x16.png',
                'js_onclick' => "$(this).next().simulate('click');",
                'overlay' => $dropdownButtons
            ];

            // Configure command buttons in navbar
            
            isys_component_template_navbar::getInstance()
                ->append_button('OpenCelium', 'becon_oc', $navbarButtonOptions)
                ->set_overlay($dropdownButtons, 'becon_oc');
        }

    }



}
