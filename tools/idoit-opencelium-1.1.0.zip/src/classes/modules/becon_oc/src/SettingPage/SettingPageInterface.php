<?php

namespace idoit\Module\Becon_Oc\SettingPage;

/**
 * Interface SettingPageInterface.
 *
 * @package idoit\Module\Becon_Oc\SettingPage
 */
interface SettingPageInterface
{
    /**
     * @param integer $navMode
     *
     * @return void
     */
    public function renderPage($navMode);

    /**
     * @param  string $function
     * @param  array  $postData
     *
     * @return array|mixed
     */
    public function processAjax($function, array $postData);
}
