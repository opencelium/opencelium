<?php
/**
 * i-doit
 *
 * "becon_OC" Module language file.
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */

return [
    'LC__MODULE__BECON_OC'                                          => 'OpenCelium',
    'LC__MODULE__BECON_OC__CONFIGURATION'                           => 'Web hook configuration',
    'LC__MODULE__BECON_OC__CALL_HOOK'                               => 'Call web hooks',
    'LC__MODULE__BECON_OC__CONFIG__HEADLINE'                        => 'OpenCelium web hook configuration',
    'LC__MODULE__BECON_OC__CONFIG__DESCRIPTION'                     => 'Please choose, for which object types and/or categories the webhooks should be displayed:',
    'LC__MODULE__BECON_OC__CONFIG__HOOK_PLACEHOLDER'                => 'You can use the following placeholders:',
    'LC__MODULE__BECON_OC__CONFIG_SAVE_SUCCESS'                     => 'Configuration successfully saved.',
    'LC__MODULE__BECON_OC__CONFIG_SAVE_ERROR'                       => 'Configuration could not be saved.',
    'LC__MODULE__BECON_OC__CONFIG_HOOK_NAME'                        => 'Name',
    'LC__MODULE__BECON_OC__CONFIG_HOOK_URL'                         => 'URL',
    'LC__MODULE__BECON_OC__CONFIG_ACTION'                           => 'Action',
    'LC__MODULE__BECON_OC__URL_NOT_CONFIGURED'                      => 'Web hook url is not configured',
    'LC__MODULE__BECON_OC__URL_NOT_AVAILABLE'                       => 'Web hook url can not be called. Maybe server is not reachable or DNS resolution failed.',
    'LC__MODULE__BECON_OC__URL_NOT_OK'                              => 'Server responded with code',
    'LC__MODULE__BECON_OC__NO_CONFIGURATION_SELECTED'               => 'No web hook configuration selected.',
    'LC__MODULE__BECON_OC__HOOKS_DEFINED'                           => 'Web hooks defined',
    'LC__MODULE__BECON_OC__CONFIG_ADD_HOOK'                         => 'New web hook',
    'LC__MODULE__BECON_OC__OBJECT_TYPES'                            => 'Object types',
    'LC__MODULE__BECON_OC__CATEGORIES'                              => 'Categories',
    'LC__MODULE__BECON_OC__HOOKS'                                   => 'Web hooks',
    'LC__MODULE__BECON_OC__ALL_OBJECTTYPES'                         => 'All',
    'LC__MODULE__BECON_OC__CONFIG__IPV4'                            => 'IPv4 address of current single host address entry. If not in single hostaddress view, the primary ip address will be used.',
    'LC__MODULE__BECON_OC__CONFIG__HOSTNAME'                        => 'Hostname of current single host address entry. If not in single hostaddress view, hostname of primary entry will be used.',
    'LC__MODULE__BECON_OC__CONFIG__FQDN'                            => 'FQDN of the current single host address entry. If not in single hostaddress view, FQDN of primary entry will be used.',
    'LC__MODULE__BECON_OC__CONFIG__OBJID'                           => 'Object ID of current object.',
    'LC__MODULE__BECON_OC__CONFIG__OBJTITLE'                        => 'Title of current object.',
    'LC__MODULE__BECON_OC__CONFIG__CATGID'                          => 'Categorie ID of current global category.',
    'LC__MODULE__BECON_OC__CONFIG__CATEID'                          => 'ID of current category entry (only multivalue categories)',
];