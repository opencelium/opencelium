<?php
use idoit\AddOn\ActivatableInterface;
use idoit\AddOn\InstallableInterface;
use idoit\Module\Beconoc\SettingPage\OcConfiguration\OcConfiguration;
use idoit\Module\Beconoc\SettingPage\Triggers\Triggers;
use idoit\Module\Beconoc\SettingPage\SettingPageInterface;
use idoit\Module\Beconoc\Model\Config;
use idoit\Module\Beconoc\Model\Trigger;


/**
 * i-doit
 *
 * becon_OC module class.
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_module_becon_oc extends isys_module implements isys_module_interface, isys_module_authable, InstallableInterface
{
    // Define, if this module shall be displayed in the named menus.
    const DISPLAY_IN_MAIN_MENU   = true;
    const DISPLAY_IN_SYSTEM_MENU = false;

    const TYPE_HTTP      = 1;
    const TYPE_SHELL    = 3;

    /**
     * Variable which holds the becon_oc DAO class.
     *
     * @var  isys_becon_oc_dao
     */
    protected $m_dao;

    /**
     * Variable which holds the database component.
     *
     * @var  isys_component_database
     */
    protected $m_db;

    /**
     * Variable which holds the template component.
     *
     * @var  isys_component_template
     */
    protected $m_tpl;


    public static function get_module_www_dir(){
        global $g_config;

        return $g_config['www_dir'] . 'src/classes/modules/becon_oc/';   
    }
    

    public static function get_assets_www_dir(){
        global $g_config;

        return $g_config['www_dir'] . 'src/classes/modules/becon_oc/assets/';   
    }


    /**
     * Static method for retrieving the path, to the modules templates.
     *
     * @static
     * @return  string
     */
    public static function get_tpl_dir()
    {
        return __DIR__ . '/templates/';
    }

    /**
     * Get related auth class for module
     *
     * @static
     * @return isys_auth
     */
    public static function get_auth()
    {
        return isys_auth_becon_oc::instance();
    }

    /**
     * Initializes the module.
     *
     * @param   isys_module_request & $p_req
     *
     * @return  isys_module_becon_oc
     */
    public function init(isys_module_request $p_req)
    {
        $this->m_db = $p_req->get_database();
        $this->m_tpl = $p_req->get_template();
        $this->m_tpl->appendJavascript(self::get_assets_www_dir() . 'js/becon_oc.js');

        return $this;
    }

    /**
     * This method builds the tree for the menu.
     *
     * @param   isys_component_tree $p_tree
     * @param   boolean             $p_system_module
     * @param   integer             $p_parent
     *
     * @author  Leonard Fischer <lfischer@i-doit.com>
     * @see     isys_module_cmdb->build_tree();
     */
    public function build_tree(isys_component_tree $p_tree, $p_system_module = true, $p_parent = null)
    {

        $imagesBase = self::get_assets_www_dir() . 'images/';
        $auth = self::get_auth();

        $p_tree->set_tree_sort(false);

        // Check whether system menu mode is active
        if (!$p_system_module) {

            $rootNode = $p_tree->add_node(
                C__MODULE__BECON_OC.'001', 
                $p_parent, 
                $this->language->get('LC__MODULE__BECON_OC'), 
                '',
                '',
                $imagesBase.'opencelium_16x16.png'
            );


            $p_tree->add_node(
                C__MODULE__BECON_OC . '002',
                $rootNode,
                $this->language->get('LC__MODULE__BECON_OC__TRIGGERS'),
                isys_helper_link::create_url([
                    C__GET__MODULE_ID     => C__MODULE__BECON_OC,
                    C__GET__SETTINGS_PAGE => 'triggers',
                    C__GET__TREE_NODE     => C__MODULE__BECON_OC . '002'
                ]),
                '',
                'images/icons/silk/script_gear.png',
                (empty($_GET[C__GET__SETTINGS_PAGE]) || $_GET[C__GET__SETTINGS_PAGE] == 'triggers'),
                '',
                '',
                $auth->is_allowed_to(isys_auth::VIEW, 'becon_oc_triggers')
            );
            $p_tree->add_node(
                C__MODULE__BECON_OC . '003',
                $rootNode,
                $this->language->get('LC__MODULE__BECON_OC__CONFIGURATION'),
                isys_helper_link::create_url([
                    C__GET__MODULE_ID     => C__MODULE__BECON_OC,
                    C__GET__SETTINGS_PAGE => 'oc_config',
                    C__GET__TREE_NODE     => C__MODULE__BECON_OC . '003'
                ]),
                '',
                'images/icons/silk/tag_blue_edit.png',
                $_GET[C__GET__SETTINGS_PAGE] == 'oc_config',
                '',
                '',
                $auth->is_allowed_to(isys_auth::VIEW, 'becon_oc_config')
            );
        }
    }

    /**
     * Start method.
     */
    public function start()
    {
        //$this->m_dao = new isys_becon_oc_dao($this->m_db);
        $defaultPage = 'triggers';
        $selectedNode = $_GET[C__GET__TREE_NODE] ?: defined_or_default('C__MODULE__BECON_OC') . '002';
        // Build the module tree, but only if we are not in the system-module.
        if ($_GET[C__GET__MODULE_ID] != C__MODULE__SYSTEM) {
            $l_tree = isys_component_tree::factory();

            $this->build_tree($l_tree, false, -1);

            $this->m_tpl->assign('menu_tree', $l_tree->process($selectedNode));

            $defaultPage = 'triggers';
        }

        $page = $_GET[C__GET__SETTINGS_PAGE] ?: $defaultPage;

        $pageList = [
            'triggers'   => Triggers::class,
            'oc_config'   => OcConfiguration::class,
        ];

        if (!isset($pageList[$page])) {
            $page = $defaultPage;
        }

        $settingPage = new $pageList[$page]($this->m_tpl, $this->m_db, $this->language);
        $settingPage->renderPage((int)($_POST[C__GET__NAVMODE] ?: $_GET[C__GET__NAVMODE]));

    }


    /**
     * Checks if a add-on is installed.
     *
     * @return int|bool
     */
    public static function isInstalled()
    {
        return isys_module_manager::instance()->is_installed('becon_oc');
    }


    /**
     * Basic installation process for all mandators.
     *
     * @param  isys_component_database $tenantDatabase
     * @param  isys_component_database $systemDatabase
     * @param  integer                 $moduleId
     * @param  string                  $type
     * @param  integer                 $tenantId
     *
     * @since  i-doit 1.12
     * @return void
     */
    public static function install($tenantDatabase, $systemDatabase, $moduleId, $type, $tenantId)
    {
        if ($type === 'install') {
            // Logic for installation.
        }
     
        if ($type === 'update') {
            require_once __DIR__ . '/src/Model/Config.php';
            require_once __DIR__ . '/src/Model/Trigger.php';
            $triggerModel = new Trigger($tenantDatabase);
            $configModel = new Config($tenantDatabase);
            $configs = $configModel->getConfigs()->__as_array();
            foreach($configs as $config){
                $hooks = json_decode($config['hooks'],true);
                foreach($hooks as &$hook){
                    if(empty($hook['trigger_id']) && !empty($hook['url'])){
                        $parsed_url = explode('?',$hook['url']);
                        $data = [
                            'name'         => $hook['name'],
                            'token'        => self::generate_string(),
                            'icon'         => 'OpenCelium.png',
                            'type'         => self::TYPE_HTTP,
                            'target'       => $parsed_url[0],
                            'parameter'    => $parsed_url[1]??''
                        ];
                        $trigger_id = $triggerModel->saveTrigger(null,$data);
                        if(!empty($trigger_id)){
                            $hook['trigger_id'] = $trigger_id;
                            unset($hook['url']);
                        }
                    }
                }
                $configModel->saveConfig($config['id'],['hooks'=>json_encode($hooks)]);
            }
        }
    }
     
    /**
     * Uninstall add-on for all mandators
     *
     * @return void
     */
    public static function uninstall($tenantDatabase)
    {
       // Custom logic...
    }

    public static function replace_placeholders($url,$objID,$catgID,$catsID,$catcID,$cateID,$selObjIDs,$encodeType = 'url'){
        $db = isys_application::instance()->container->get('database');
        $l_replace_pairs = [
            '%ipv4%' => [],
            '%hostname%' => [],
            '%fqdn%' => [],
            '%objid%' => [],
            '%objtitle%' => [],
            '%objid_sel%' => [],
            '%objtitle_sel%' => [],
            '%catgid%' => '',
            '%catsid%' => '',
            '%catcid%' => '',
            '%cateid%' => [],
        ];
        $objIdArr = [];
        $dataIds = [];
        /*
        if(!empty($objID)){
            $objIdArr = explode(";",$objID);
        }
        */
        if(!empty($selObjIDs)){
            $objIdArr = explode(";",$selObjIDs);
        } elseif(!empty($objID)) {
            $objIdArr[] = $objID;
        }
        if(!empty($cateID)){
            $dataIds = explode(",",$cateID);
        }
        foreach($objIdArr as $id){
            list($selObjId,$dataId) = explode(",",$id);
            $l_dao_ip = isys_cmdb_dao_category_g_ip::instance($db);
            if(!empty($catgID)){
                $l_replace_pairs['%catgid%'] = $catgID;
                if(!empty($cateID)){
                    $l_replace_pairs['%cateid%'] = $dataIds;
                }
            } elseif(!empty($catsID)){
                $l_replace_pairs['%catsid%'] = $catsID;
                if($catsID == C__CATS__NET_IP_ADDRESSES && !empty($dataId)){
                    $l_replace_pairs['%cateid%'][] = $dataId;
                } elseif(!empty($cateID) && count($objIds) == 1){
                    $l_replace_pairs['%cateid%'] = $dataIds;
                }
            }
            if($catgID == C__CATG__CUSTOM_FIELDS && !empty($catcID)){
                $l_replace_pairs['%catcid%'] = $catcID;
            }
            if($catgID == C__CATG__IP && !empty($dataIds)){
                $l_replace_pairs['%objid%'][] = $selObjId;
                $l_replace_pairs['%objtitle%'][] = self::encode_params($l_dao_ip->obj_get_title_by_id_as_string($selObjId),$encodeType);
                foreach($dataIds as $entryId){
                    $data = $l_dao_ip->get_data_as_array($entryId,$selObjId);
                    $l_replace_pairs['%ipv4%'][] = self::encode_params($data[0]['isys_cats_net_ip_addresses_list__title'],$encodeType);
                    $l_replace_pairs['%hostname%'][] = self::encode_params($data[0]['isys_catg_ip_list__hostname'],$encodeType);
                    $fqdn = $data[0]['isys_catg_ip_list__hostname'];
                    if(!empty($fqdn) && !empty($data[0]['isys_catg_ip_list__domain'])){
                        $fqdn .= ".".$data[0]['isys_catg_ip_list__domain'];
                    }
                    $l_replace_pairs['%fqdn%'][] = self::encode_params($fqdn,$encodeType);
                }
            } elseif($catsID == C__CATS__NET_IP_ADDRESSES && !empty($dataId)){
                $data = $l_dao_ip->get_data_as_array($dataId,$selObjId);
                $l_replace_pairs['%objid%'] = $objID;
                $l_replace_pairs['%objtitle%'] = self::encode_params($l_dao_ip->obj_get_title_by_id_as_string($objID),$encodeType);
                $l_replace_pairs['%objid_sel%'][] = $selObjId;
                $l_replace_pairs['%objtitle_sel%'][] = self::encode_params($l_dao_ip->obj_get_title_by_id_as_string($selObjId),$encodeType);
                $l_replace_pairs['%ipv4%'][] = self::encode_params($data[0]['isys_cats_net_ip_addresses_list__title'],$encodeType);
                $l_replace_pairs['%hostname%'][] = self::encode_params($data[0]['isys_catg_ip_list__hostname'],$encodeType);
                $fqdn = $data[0]['isys_catg_ip_list__hostname'];
                if(!empty($fqdn) && !empty($data[0]['isys_catg_ip_list__domain'])){
                    $fqdn .= ".".$data[0]['isys_catg_ip_list__domain'];
                }
                $l_replace_pairs['%fqdn%'][] = self::encode_params($fqdn,$encodeType);
            } else {
                $l_replace_pairs['%objid%'][] = $selObjId;
                $l_replace_pairs['%objtitle%'][] = self::encode_params($l_dao_ip->obj_get_title_by_id_as_string($selObjId),$encodeType);
                $l_primary_ip_data = $l_dao_ip->get_primary_ip($selObjId)->get_row();
                $l_replace_pairs['%ipv4%'][] = self::encode_params($l_primary_ip_data['isys_cats_net_ip_addresses_list__title'],$encodeType);
                $l_replace_pairs['%hostname%'][] = self::encode_params($l_primary_ip_data['isys_catg_ip_list__hostname'],$encodeType);
                $fqdn = $l_primary_ip_data['isys_catg_ip_list__hostname'];
                if(!empty($fqdn) && !empty($l_primary_ip_data['isys_catg_ip_list__domain'])){
                    $fqdn .= ".".$l_primary_ip_data['isys_catg_ip_list__domain'];
                }
                $l_replace_pairs['%fqdn%'][] = self::encode_params($fqdn,$encodeType);
            }
        }
        $l_replace_pairs_as_arr = [];
        foreach($l_replace_pairs as $key => &$targetString){
            if(is_array($targetString)){
                if(count($targetString) == 0){
                    $l_replace_pairs_as_arr['['.$key.']'] = self::encode_params("[]",$encodeType);
                    $targetString = '';
                } else {
                    $l_replace_pairs_as_arr['['.$key.']'] = self::encode_params("[",$encodeType)."'".implode("','",$targetString)."'".self::encode_params("]",$encodeType);
                    $targetString = self::encode_params(implode(",",$targetString),$encodeType);
                }
            } else {
                if($key != '%catgid%' && $key != '%catsid%' && $key != '%catcid%' && $key != '%objid%'){
                    if($key == '%objtitle%'){
                        $targetString = self::encode_params($targetString,$encodeType);
                    } elseif(empty($targetString)){
                        $l_replace_pairs_as_arr['['.$key.']'] = self::encode_params("[]",$encodeType);
                        $targetString = '';
                    } else {
                        $l_replace_pairs_as_arr['['.$key.']'] = self::encode_params("[",$encodeType)."'".$targetString."'".self::encode_params("]",$encodeType);
                        $targetString = self::encode_params($targetString,$encodeType);
                    }
                }
            }
        }
        $returnString = strtr($url, $l_replace_pairs_as_arr);
        $returnString = strtr($returnString, $l_replace_pairs);
        return $returnString;
    }

    private static function encode_params($param,$encoding_type){
        if($encoding_type == 'url'){
            return urlencode($param);
        }
        return $param;
    }

    /**
     * Adds OpenCelium Button, if configured
     *
     * @return int|bool
     */
    public static function addButton()
    {
        $imagesBase = self::get_assets_www_dir() . 'images/';
        $db = isys_application::instance()->container->get('database');
        $dao = isys_cmdb_dao::instance($db);
        $auth = self::get_auth();
        $triggerModel = new Trigger($db);
        $configModel = new Config($db);
        $configs = $configModel->getConfigs()->__as_array();
        $dropdownLinks = [];

        $objTypeOnly = [];
        $category_g_only = [];
        $category_s_only = [];
        $category_c_only = [];
        $objTypeAndCategoryG = [];
        $objTypeAndCategoryS = [];
        $objTypeAndCategoryC = [];

        foreach($configs as $conf){
            $objectTypes = [];
            if(!empty($conf['object_types'])) {
                $objectTypes =  explode(",",$conf['object_types']);
            }
            $categories = [];
            if(!empty($conf['categories'])) {
                $categories =  explode(",",$conf['categories']);
            }
            $categories_s = [];
            if(!empty($conf['categories_s'])) {
                $categories_s =  explode(",",$conf['categories_s']);
            }
            $categories_c = [];
            if(!empty($conf['categories_c'])) {
                $categories_c =  explode(",",$conf['categories_c']);
            }

            if(!empty($objectTypes) && empty($categories) && empty($categories_s) && empty($categories_c)){
                foreach($objectTypes as $objType){
                    if(empty($objTypeOnly[$objType])){
                        $objTypeOnly[$objType] = [];
                    }
                    $hooks = json_decode($conf['hooks'],true);
                    array_push($objTypeOnly[$objType], ...$hooks);
                }
            } elseif(empty($objectTypes) && !empty($categories)){
                foreach($categories as $catg){
                    if(empty($category_g_only[$catg])){
                        $category_g_only[$catg] = [];
                    }
                    $hooks = json_decode($conf['hooks'],true);
                    array_push($category_g_only[$catg],...$hooks);
                }
            } elseif(empty($objectTypes) && !empty($categories_s)){
                foreach($categories_s as $cats){
                    if(empty($category_s_only[$cats])){
                        $category_s_only[$cats] = [];
                    }
                    $hooks = json_decode($conf['hooks'],true);
                    array_push($category_s_only[$cats],...$hooks);
                }
            } elseif(empty($objectTypes) && !empty($categories_c)){
                foreach($categories_c as $catc){
                    if(empty($category_c_only[$catc])){
                        $category_c_only[$catc] = [];
                    }
                    $hooks = json_decode($conf['hooks'],true);
                    array_push($category_c_only[$catc],...$hooks);
                }
            } elseif(!empty($objectTypes) && !empty($categories)){
                foreach($categories as $catg){
                    if(empty($objTypeAndCategoryG[$catg])){
                        $objTypeAndCategoryG[$catg] = [];
                    }
                    foreach($objectTypes as $objType){
                        if(empty($objTypeAndCategoryG[$catg][$objType])){
                            $objTypeAndCategoryG[$catg][$objType] = [];
                        }
                        $hooks = json_decode($conf['hooks'],true);    
                        array_push($objTypeAndCategoryG[$catg][$objType],...$hooks);
                    }
                }
            } elseif(!empty($objectTypes) && !empty($categories_s)){
                foreach($categories_s as $cats){
                    if(empty($objTypeAndCategoryS[$cats])){
                        $objTypeAndCategoryS[$cats] = [];
                    }
                    foreach($objectTypes as $objType){
                        if(empty($objTypeAndCategoryS[$cats][$objType])){
                            $objTypeAndCategoryS[$cats][$objType] = [];
                        }
                        $hooks = json_decode($conf['hooks'],true);    
                        array_push($objTypeAndCategoryS[$cats][$objType],...$hooks);
                    }
                }
            } elseif(!empty($objectTypes) && !empty($categories_c)){
                foreach($categories_c as $catc){
                    if(empty($objTypeAndCategoryC[$catc])){
                        $objTypeAndCategoryC[$catc] = [];
                    }
                    foreach($objectTypes as $objType){
                        if(empty($objTypeAndCategoryC[$catc][$objType])){
                            $objTypeAndCategoryC[$catc][$objType] = [];
                        }
                        $hooks = json_decode($conf['hooks'],true);    
                        array_push($objTypeAndCategoryC[$catc][$objType],...$hooks);
                    }
                }
            }
        }

        if(!empty($_GET['objTypeID']) && !empty($objTypeOnly[$_GET['objTypeID']])){
            foreach ($objTypeOnly[$_GET['objTypeID']] as $hook) {
                $dropdownLinks[] = [
                    'title'   => $hook['name'],
                    'href'    => 'javascript:;',
                    'trigger_id' => $hook['trigger_id'],
                ];
            }
        }
        if(!empty($_GET['catgID']) && !empty($_GET['objID']) && !empty($category_g_only[$_GET['catgID']])){
            foreach ($category_g_only[$_GET['catgID']] as $hook) {
                $dropdownLinks[] = [
                    'title'   => $hook['name'],
                    'href'    => 'javascript:;',
                    'trigger_id' => $hook['trigger_id'],
                ];
            }
        }
        if(!empty($_GET['catsID']) && !empty($_GET['objID']) && !empty($category_s_only[$_GET['catsID']])){
            foreach ($category_s_only[$_GET['catsID']] as $hook) {
                $dropdownLinks[] = [
                    'title'   => $hook['name'],
                    'href'    => 'javascript:;',
                    'trigger_id' => $hook['trigger_id'],
                ];
            }
        }
        if(!empty($_GET['customID']) && !empty($_GET['objID']) && !empty($_GET['catgID']) && $_GET['catgID']==C__CATG__CUSTOM_FIELDS && !empty($category_c_only[$_GET['customID']])){
            foreach ($category_c_only[$_GET['customID']] as $hook) {
                $dropdownLinks[] = [
                    'title'   => $hook['name'],
                    'href'    => 'javascript:;',
                    'trigger_id' => $hook['trigger_id'],
                ];
            }
        }
        if(!empty($_GET['catgID']) && !empty($_GET['objID']) && !empty($objTypeAndCategoryG[$_GET['catgID']])){
            $obj_data = $dao->get_object_by_id($_GET['objID'])->get_row();
            if(!empty($objTypeAndCategoryG[$_GET['catgID']][$obj_data['isys_obj_type__id']])){
                foreach ($objTypeAndCategoryG[$_GET['catgID']][$obj_data['isys_obj_type__id']] as $hook) {
                    $dropdownLinks[] = [
                        'title'   => $hook['name'],
                        'href'    => 'javascript:;',
                        'trigger_id' => $hook['trigger_id'],
                    ];
                }
            }
        }
        if(!empty($_GET['catsID']) && !empty($_GET['objID']) && !empty($objTypeAndCategoryS[$_GET['catsID']])){
            $obj_data = $dao->get_object_by_id($_GET['objID'])->get_row();
            if(!empty($objTypeAndCategoryS[$_GET['catsID']][$obj_data['isys_obj_type__id']])){
                foreach ($objTypeAndCategoryS[$_GET['catsID']][$obj_data['isys_obj_type__id']] as $hook) {
                    $dropdownLinks[] = [
                        'title'   => $hook['name'],
                        'href'    => 'javascript:;',
                        'trigger_id' => $hook['trigger_id'],
                    ];
                }
            }
        }
        if(!empty($_GET['customID']) && !empty($_GET['objID']) && !empty($objTypeAndCategoryC[$_GET['customID']])){
            $obj_data = $dao->get_object_by_id($_GET['objID'])->get_row();
            if(!empty($objTypeAndCategoryC[$_GET['customID']][$obj_data['isys_obj_type__id']])){
                foreach ($objTypeAndCategoryC[$_GET['customID']][$obj_data['isys_obj_type__id']] as $hook) {
                    $dropdownLinks[] = [
                        'title'   => $hook['name'],
                        'href'    => 'javascript:;',
                        'trigger_id' => $hook['trigger_id'],
                    ];
                }
            }
        }
        $objID = (int) $_GET['objID'] ?? 0;
        $catgID = (int) $_GET['catgID'] ?? 0;
        $catsID = (int) $_GET['catsID'] ?? 0;
        $catcID = (int) $_GET['customID'] ?? 0;
        $cateID = 0;
        if(!empty($_GET['cateID'])){
            $cateID = (int) $_GET['cateID'];
        } elseif(!empty($_POST['id'][0]) && count($_POST['id']) == 1){
            $cateID = (int) $_POST['id'][0];
        }

        $groupButtons = [];

        foreach($dropdownLinks as $key=>$elem){
            $trigger = $triggerModel->getTrigger($elem['trigger_id'])->get_row();
            $is_allowed = $auth->is_allowed_to(isys_auth::EXECUTE, 'BECON_OC_EXECUTE_TRIGGER/'.$trigger['token']);

            if($is_allowed){

                $linkIcon = 'icons/silk/link_go.png';
                if($trigger['type'] == self::TYPE_SHELL){
                    $linkIcon = 'icons/silk/application_osx_terminal.png';
                }
                if(!empty($trigger['icon'])){
                    $dropdownLinks[$key]['icon'] = $linkIcon;
                }
                $dropdownLinks[$key]['onclick'] = "window.executeTrigger(this,'{$trigger['token']}',$objID,$catgID,$catsID,$cateID,$catcID)";
                unset($dropdownLinks[$key]['trigger_id']);
                $groupName = self::getGroupNameByImage($trigger['icon']);
                if(!isset($groupButtons[$groupName])){
                    $groupButtons[$groupName] = [
                        'icon' => $trigger['icon'],
                        'dropdownLinks' => []
                    ];
                }
                $groupButtons[$groupName]['dropdownLinks'][] = $dropdownLinks[$key];
            }
        }

        $counter = 0;
        foreach($groupButtons as $buttonName=>$buttonData){
            $button_identifier = 'becon_oc_buttons'.$counter++;
            $navbarButtonOptions = [
                'active'     => true,
                'visible'    => true,
                'navmode'    => $button_identifier,
                'icon'       => self::get_assets_www_dir().'images/icons/'.$buttonData['icon'],
                'js_onclick' => "$(this).next().simulate('click');",
                'overlay'    => $buttonData['dropdownLinks']
            ];

            // Configure command buttons in navbar
            isys_component_template_navbar::getInstance()
                ->append_button($buttonName, $button_identifier, $navbarButtonOptions)
                ->set_overlay($buttonData['dropdownLinks'], $button_identifier);
        }

    }

    public static function getGroupNameByImage($imageName){
        $nameArr = pathinfo($imageName);
        return str_replace(['_'],[' '],$nameArr['filename']);
    }

    public static function generate_string($strength = 32) {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789';
        $input_length = strlen($chars);
        $random_string = '';
        for($i = 0; $i < $strength; $i++) {
            $random_character = $chars[random_int(0, $input_length - 1)];
            $random_string .= $random_character;
        }
     
        return $random_string;
    }
}
