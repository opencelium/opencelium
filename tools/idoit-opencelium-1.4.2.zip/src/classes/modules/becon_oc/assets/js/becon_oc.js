window.executeTrigger = function executeTrigger(commandLinkElement, $token, objId, catgId, catsId, cateId, catcId) {
    //var $overlay             = $('new_overlay_becon_oc')
    var $overlay             = $(commandLinkElement).up('div');
    var $clickedElementImage = $(commandLinkElement).down('img');
    var currentImageSource   = $clickedElementImage.readAttribute('src');
    var selectedRows = $$('tr.tr-selected');
    var selectedIds = [];
    var selectedObjIds = [];
    var selectedDataIds = [];
    if(selectedRows.length == 0){
        var selectedIpRows = $$('#ip-table-body td.check.sel');
        selectedIpRows.forEach(function(selectedTd){
          var selectedRow = selectedTd.up();
          var rowObjId = selectedRow.readAttribute('data-obj-id');
          if(rowObjId){
            selectedObjIds.push(rowObjId+','+selectedRow.readAttribute('data-id'));
            //selectedDataIds.push(selectedRow.readAttribute('data-id'));
          }
        });        
    } else {
        selectedRows.forEach(function(selectedRow){
          if(objId){
            selectedDataIds.push(selectedRow.readAttribute('data-id'));
          } else {
            selectedIds.push(selectedRow.readAttribute('data-id'));
          }
        });    
    }
    
    
    var selObjIds = null;
    if(selectedObjIds.length){
        selObjIds = selectedObjIds.join(";");
    } else if(selectedIds.length){
        selObjIds = selectedIds.join(";");
    }

    if(selectedDataIds.length){
        cateId = selectedDataIds.join(",");
    }

    $clickedElementImage.writeAttribute('src', 'images/ajax-loading.gif');

    // Disable command buttons
    $overlay.select('a').invoke('addClassName', 'non-clickable');

    var params = {
        ajax:        1,
        call:        'becon_oc',
        func:        'executeTrigger',
        token:       $token,
        objID:       objId,
        catgID:      catgId,
        catsID:      catsId,
        catcID:      catcId, 
        cateID:      cateId,
        selObjIDs:   selObjIds
    };

    new Ajax.Request('?' + Object.toQueryString(params), {
        onSuccess: function (response) {
            // Parse JSON
            response = JSON.parse(response.responseText);

            // Enable command buttons
            $overlay.select('a').invoke('removeClassName', 'non-clickable');

            // Restore image src again
            $clickedElementImage.writeAttribute('src', currentImageSource);

            if (response.success) {
                idoit.Notify.success(response.message);
            } else {
                idoit.Notify.error(response.message);
            }
        }
    });
}
