<?php

use idoit\Module\Beconoc\Model\Trigger;

/**
 * i-doit
 *
 * Auth: Class for i-doit authorization rules.
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */

class isys_auth_becon_oc extends isys_auth implements isys_auth_interface
{
    /**
     * Container for singleton instance
     *
     * @var isys_auth_becon_oc
     */
    private static $m_instance;

    /**
     * Retrieve singleton instance of authorization class
     *
     * @return isys_auth_becon_oc
     * @author Selcuk Kekec <skekec@i-doit.com>
     */
    public static function instance()
    {
        // If the DAO has not been loaded yet, we initialize it now.
        if (self::$m_dao === null) {
            //global $g_comp_database;

            self::$m_dao = new isys_auth_dao(isys_application::instance()->container->get('database'));
        }

        if (self::$m_instance === null) {
            self::$m_instance = new self;
        }

        return self::$m_instance;
    }

    /**
     * Method for retrieving the "parameter" in the configuration GUI. Gets called generically by "ajax()" method.
     *
     * @see     isys_module_auth->ajax_retrieve_parameter();
     *
     * @param   string  $p_method
     * @param   string  $p_param
     * @param   integer $p_counter
     * @param   boolean $p_editmode
     * @param   boolean $p_combo_param This parameter is used, when more than one box is displayed at once (category in object, ...).
     *
     * @return  array
     * @throws  isys_exception_database
     * @author  Leonard Fischer <lfischer@synetics.de>
     */
    public function retrieve_parameter($p_method, $p_param, $p_counter, $p_editmode = false, $p_combo_param = false)
    {
        global $g_comp_database;

        $l_return = [
            'html'    => '',
            'method'  => $p_method,
            'param'   => $p_param,
            'counter' => $p_counter
        ];

        $triggerModel = new Trigger($g_comp_database);

        switch ($p_method) {
            case 'becon_oc_execute_trigger':
                // Init the dialog admin.
                $triggers = $triggerModel->getTriggers()->__as_array();
                
                //$l_tables = isys_dialog_admin_dao::instance($g_comp_database)
                //    ->get_dialog_tables();
                $l_data = [];

                // Bring the tables in the needed syntax.
                foreach ($triggers as $trigger) {
                    $l_data[$trigger['token']] = $trigger['name'];
                }

                $l_dialog = new isys_smarty_plugin_f_dialog();
                $l_params = [
                    'name'              => 'auth_param_form_' . $p_counter . '[]',
                    'p_arData'          => $l_data,
                    'p_editMode'        => $p_editmode,
                    'p_bDbFieldNN'      => 1,
                    'p_bInfoIconSpacer' => 0,
                    'p_strClass'        => 'input-small',
                    'p_strSelectedID'   => strtoupper($p_param),
                    'p_multiple'        => true,
                    'chosen'            => true,
                    'placeholder'       => 'LC__MODULE__BECON_OC__SELECT_TRIGGERS',
                ];

                $l_return['html'] = $l_dialog->navigation_edit(isys_application::instance()->template, $l_params);
                break;
        }

        return $l_return;
    }

    /**
     * Optional method for combining auth paths.
     *
     * @param   array &$p_paths
     *
     * @return  isys_auth_cmdb
     * @author  Leonard Fischer <lficsher@i-doit.com>
     */
    public function combine_paths(array &$p_paths)
    {
        foreach ($p_paths as $l_method => $l_params) {
            $p_paths[$l_method] = self::combine_simple_values($l_params);
        }

        return $this;
    }

    /**
     * Protected method for combining "category" paths.
     *
     * @static
     *
     * @param   array $p_category_paths
     *
     * @return  array
     * @author  Leonard Fischer <lficsher@i-doit.com>
     */
    protected static function combine_simple_values(array &$p_category_paths)
    {
        // Prepare some variables.
        $l_return = [];
        $l_keys = [];
        $l_last_rights_num = 0;

        // Sort the parameters, so that the foreach will do its job correctly.
        isys_auth::sort_paths_by_rights($p_category_paths);

        foreach ($p_category_paths as $l_key => $l_rights) {
            if ($l_key == self::WILDCHAR || $l_key == self::EMPTY_ID_PARAM) {
                $l_return[$l_key] = $l_rights;
                continue;
            }

            $l_rights_num = array_sum($l_rights);

            if ($l_last_rights_num == $l_rights_num) {
                $l_keys[] = $l_key;
            } else {
                if (count($l_keys)) {
                    $l_return[implode(',', $l_keys)] = isys_helper::split_bitwise($l_last_rights_num);
                }

                $l_keys = [$l_key];
            }

            $l_last_rights_num = $l_rights_num;
        }

        if (count($l_keys)) {
            $l_return[implode(',', $l_keys)] = isys_helper::split_bitwise($l_last_rights_num);
        }

        return $l_return;
    }


    /**
     * Method for returning the available auth-methods. This will be used for the GUI.
     *
     * @return  array
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function get_auth_methods()
    {
        return [
            'becon_oc_config'   => [
                'title'  => 'LC__MODULE__BECON_OC__CONFIGURATION',
                'type'   => 'boolean',
                'rights' => [
                    isys_auth::VIEW,
                    isys_auth::EDIT
                ]
            ],
            'becon_oc_triggers'   => [
                'title'  => 'LC__MODULE__BECON_OC__TRIGGERS',
                'type'   => 'boolean',
                'rights' => [
                    isys_auth::VIEW,
                    isys_auth::EDIT
                ]
            ],
            'becon_oc_execute_trigger'   => [
                'title'  => 'LC__MODULE__BECON_OC__EXECUTE_TRIGGER',
                'type'   => 'becon_oc_execute_trigger',
                'rights' => [
                    isys_auth::EXECUTE
                ]
            ],
            
        ];
    }

    /**
     * Get ID of related module
     *
     * @return int
     */
    public function get_module_id()
    {
        return C__MODULE__BECON_OC;
    }

    /**
     * Get title of related module
     *
     * @return string
     */
    public function get_module_title()
    {
        return "LC__MODULE__BECON_OC";
    }

    /**
     * Method for checking, if the user is allowed to configure opencelium triggers.
     *
     * @param   integer $p_right
     *
     * @return  boolean
     * @throws  isys_exception_auth
     */
    public function becon_oc_config($p_right)
    {
        if (!$this->is_auth_active()) {
            return true;
        }

        return $this->generic_right(
            $p_right,
            'becon_oc_config',
            self::EMPTY_ID_PARAM,
            new isys_exception_auth(isys_application::instance()->container->get('language')->get('LC__MODULE__BECON_OC__CONFIGURATION'))
        );
    }

    /**
     * Method for checking, if the user is allowed to configure self generated triggers.
     *
     * @param   integer $p_right
     *
     * @return  boolean
     * @throws  isys_exception_auth
     */
    public function becon_oc_triggers($p_right)
    {
        if (!$this->is_auth_active()) {
            return true;
        }

        return $this->generic_right(
            $p_right,
            'becon_oc_triggers',
            self::EMPTY_ID_PARAM,
            new isys_exception_auth(isys_application::instance()->container->get('language')->get('LC__MODULE__BECON_OC__CONFIGURATION'))
        );
    }


    /**
     * Method for checking, if the user is allowed to execute trigger.
     *
     * @param   integer $p_right
     * @param   string $p_trigger_token
     *
     * @return  boolean
     * @throws  isys_exception_auth
     */
    public function becon_oc_execute_trigger($p_right, $p_trigger_token)
    {
        if (!$this->is_auth_active()) {
            return true;
        }

        return $this->check_module_rights(
            $p_right,
            'becon_oc_execute_trigger',
            $p_trigger_token,
            new isys_exception_auth(isys_application::instance()->container->get('language')
            ->get('LC__AUTH__BECON_OC_EXCEPTION__MISSING_RIGHT_FOR_EXECUTING_TRIGGER')));
    }


}
