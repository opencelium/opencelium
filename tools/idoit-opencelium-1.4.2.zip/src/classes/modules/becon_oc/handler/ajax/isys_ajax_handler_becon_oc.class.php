<?php
use idoit\Module\Beconoc\Model\Config;
use idoit\Module\Beconoc\Model\Trigger;
use isys_notify as Notify;

/**
 * i-doit
 *
 * Becon_OC Ajax handler
 *
 * @package     Handler/Ajax
 * @subpackage  becon_OpenCelium
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_ajax_handler_becon_oc extends isys_ajax_handler
{

    /**
     * Logger instance
     *
     * @var isys_log
     */
    private $logger;

    /**
     * isys_ajax_handler_cmk2_command constructor.
     *
     * @param array $get
     * @param array $post
     */
    public function __construct(array $get, array $post)
    {
        parent::__construct($get, $post);

        // Create logger
        $this->logger = isys_factory_log::get_instance('becon_oc')
            ->set_destruct_flush(false)
            ->set_log_file(null);
    }

    public function init()
    {
        // We set the header information because we don't accept anything than JSON.
        header('Content-Type: application/json');

        $ajaxReturn = [
            'success' => true,
            'message' => null
        ];

        try {
            $auth = isys_module_becon_oc::get_auth();
            switch ($this->m_get['func']) {
                case 'executeTrigger':
                    global $g_absdir;

                    // Set expiration header to 0
                    isys_core::expire(0);

                    // Check whether token is configured
                    $token_configured = false;
                    
                    $token = $this->m_get['token'];

                    $triggerModel = new Trigger(isys_application::instance()->container->get('database'));
                    $trigger = $triggerModel->getTriggerByToken($token);

                    if(!empty($trigger)){

                        if($auth->is_allowed_to(isys_auth::EXECUTE, 'BECON_OC_EXECUTE_TRIGGER/'.$trigger['token'])){

                            $objID = $this->m_get['objID'];
                            $catgID = $this->m_get['catgID'];
                            $catsID = $this->m_get['catsID'];
                            $catcID = $this->m_get['catcID'];
                            $cateID = $this->m_get['cateID'];
                            $selObjIDs = $this->m_get['selObjIDs'];
                            $target = $trigger['target'];

                            switch($trigger['type']){
                                case isys_module_becon_oc::TYPE_HTTP:
                                    $url = isys_module_becon_oc::replace_placeholders($target,$objID,$catgID,$catsID,$catcID,$cateID,$selObjIDs,'url');
                                    if(!empty($trigger['parameter'])){
                                        $url .= '?'.isys_module_becon_oc::replace_placeholders($trigger['parameter'],$objID,$catgID,$catsID,$catcID,$cateID,$selObjIDs,'url');
                                    }
                                    
                                    //init cURL with given url
                                    $curl = curl_init($url);

                                    //catch return data to not destroy our json
                                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                                    curl_setopt($curl, CURLINFO_HEADER_OUT, true);
                                    
                                    foreach($trigger['options'] as $option){
                                        //check, if curl constant is available on system
                                        if(defined($option['name'])){
                                            if($option['name'] == 'CURLOPT_POSTFIELDS'){
                                                $option['value'] = isys_module_becon_oc::replace_placeholders($option['value'],$objID,$catgID,$catsID,$catcID,$cateID,$selObjIDs,'url');
                                            }
                                            curl_setopt($curl, constant($option['name']), $option['value']);
                                        }
                                    }

                                    //execute cURL, catch response
                                    $response = curl_exec($curl);


                                    // get cURL errors, if any
                                    $err = curl_error($curl);

                                    if($err){
                                        $ajaxReturn['success'] = false;
                                        $ajaxReturn['message'] = $url . ': '.isys_application::instance()->container->get('language')
                                        ->get('LC__MODULE__BECON_OC__URL_NOT_AVAILABLE'). ', cURL error #: '.$err;
                                    } else {
                                        $reponse_code = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
                                        if($reponse_code >= 200 && $reponse_code < 300){
                                            $ajaxReturn['success'] = true;
                                            $ajaxReturn['message'] = 'Calling request: ' . $url;
                                            Notify::debug("Request: <pre>". print_r(curl_getinfo($curl, CURLINFO_HEADER_OUT),true) ."</pre>Response: <pre>HTTP code: $reponse_code\n".print_r($response,true)."</pre>",['sticky' => true]);
                                        } else {
                                            $ajaxReturn['success'] = false;
                                            $ajaxReturn['message'] = $url . ': '.isys_application::instance()->container->get('language')
                                                ->get('LC__MODULE__BECON_OC__URL_NOT_OK'). ' '.$reponse_code;
                                            Notify::debug("Request: <pre>". print_r(curl_getinfo($curl, CURLINFO_HEADER_OUT),true) ."</pre>Response: <pre>".print_r($response,true)."</pre>",['sticky' => true]);
                                        }
                                    }
                                    curl_close($curl);
                                break;
                                case isys_module_becon_oc::TYPE_SHELL:
                                    if (!file_exists($target)) {
                                        $ajaxReturn['success'] = false;
                                        $ajaxReturn['message'] = 'Command "' . $target . '" does not exist.';
                                    } elseif (!is_executable($target)) {
                                        $ajaxReturn['success'] = false;
                                        $ajaxReturn['message'] = 'Command "' . $target . '" is not executable.';
                                    } else {
                                        $parameter = isys_module_becon_oc::replace_placeholders($trigger['parameter'],$objID,$catgID,$catsID,$catcID,$cateID,$selObjIDs,'shell');
                                        exec(escapeshellcmd($target . ' ' . $parameter) . ' > /dev/null &');
                                        $ajaxReturn['success'] = true;
                                        $ajaxReturn['message'] = 'Calling command: ' . escapeshellcmd($target . ' ' . $parameter);
                                    }

                                    /*
                                    $formattedArgs = isys_format_json::encode($args);


                                    if (isys_tenantsettings::get('events.decodeArgs', 1)) {
                                        $formattedArgs = base64_encode($formattedArgs);
                                    }

                                    $l_return = [];
                                    */

                                break;
                            }

                        } else {

                            $ajaxReturn['success'] = false;
                            $ajaxReturn['message'] = $url . ': '.isys_application::instance()->container->get('language')
                                ->get('LC__AUTH__BECON_OC_EXCEPTION__MISSING_RIGHT_FOR_CALLING_SCRIPT');
                        
                        }
                        //$url = isys_module_becon_oc::replace_url_placeholders($url,$objID,$catgID,$catsID,$cateID,$selObjIDs);
                    } else {
                        // Command was not found
                        $ajaxReturn['success'] = false;
                        $ajaxReturn['message'] = $url . ': '.isys_application::instance()->container->get('language')
                            ->get('LC__MODULE__BECON_OC__TOKEN_NOT_CONFIGURED');

                    }

            }
        } catch (Exception $e) {
            $ajaxReturn['success'] = false;
            $ajaxReturn['message'] = $e->getMessage();
        }

        echo isys_format_json::encode($ajaxReturn);

        $this->_die();
    }

}
