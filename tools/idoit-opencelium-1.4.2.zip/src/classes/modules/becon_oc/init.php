<?php
/**
 * i-doit
 *
 * Module initializer
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */

use idoit\Component\Upload\Types\ObjectTypeIcon;
use idoit\Component\Upload\UploadType;

if (isys_module_manager::instance()->is_active('becon_oc')) {
    require_once __DIR__ . '/isys_module_becon_oc_autoload.class.php';

    spl_autoload_register('isys_module_becon_oc_autoload::init');

    \idoit\Psr4AutoloaderClass::factory()->addNamespace('idoit\Module\Beconoc', __DIR__ . '/src/');

    if (isys_application::instance()->container->get('session')->is_logged_in()) {
        /*
        isys_request_controller::instance()
            ->addModuleRoute('GET', '/trigger/[c:idtoken]', 'becon_oc', 'Trigger','callTrigger');
        */
        isys_component_signalcollection::get_instance()->connect(
            'system.navbar.beforeAssignment',
            [
                'isys_module_becon_oc',
                'addButton'
            ]
        );
        isys_register::factory('ajax-file-upload')
            ->set('trigger-menu-icon', (new UploadType())
                ->setUploadDirectory('/src/classes/modules/becon_oc/assets/images/icons/')
                ->setValidExtensions(['jpeg', 'jpg', 'png', 'gif', 'bmp'])
                ->setSizeLimit(1048576) // 1 MB
                ->setCallbackAfterUpload([ObjectTypeIcon::class, 'processUpload']));
    }
}
