<?php
/**
 * i-doit
 *
 * "becon_OC" Module language file.
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */

return [
    'LC__MODULE__BECON_OC'                                          => 'OpenCelium',
    'LC__MODULE__BECON_OC__CONFIGURATION'                           => 'Web hook configuration',
    'LC__MODULE__BECON_OC__CALL_SCRIPT'                             => 'Execute script',
    'LC__MODULE__BECON_OC__CONFIG__HEADLINE'                        => 'OpenCelium web hook configuration',
    'LC__MODULE__BECON_OC__CONFIG__DESCRIPTION'                     => 'Please choose, for which object types and/or categories the triggers should be displayed:',
    'LC__MODULE__BECON_OC__CONFIG__TRIGGER_PLACEHOLDER'                => 'You can use the following placeholders:',
    'LC__MODULE__BECON_OC__CONFIG_SAVE_SUCCESS'                     => 'Configuration successfully saved.',
    'LC__MODULE__BECON_OC__CONFIG_SAVE_ERROR'                       => 'Configuration could not be saved.',
    'LC__MODULE__BECON_OC__CONFIG_TRIGGER_NAME'                        => 'Name',
    'LC__MODULE__BECON_OC__CONFIG_TRIGGER_TOKEN'                         => 'TOKEN',
    'LC__MODULE__BECON_OC__CONFIG_ACTION'                           => 'Action',
    'LC__MODULE__BECON_OC__TOKEN_NOT_CONFIGURED'                      => 'Web hook url is not configured',
    'LC__MODULE__BECON_OC__URL_NOT_AVAILABLE'                       => 'Web hook url can not be called. Maybe server is not reachable or DNS resolution failed.',
    'LC__MODULE__BECON_OC__URL_NOT_OK'                              => 'Server responded with code',
    'LC__MODULE__BECON_OC__NO_CONFIGURATION_SELECTED'               => 'No web hook configuration selected.',
    'LC__MODULE__BECON_OC__HOOKS_DEFINED'                           => 'Web hooks defined',
    'LC__MODULE__BECON_OC__CONFIG_ADD_HOOK'                         => 'New web hook',
    'LC__MODULE__BECON_OC__OBJECT_TYPES'                            => 'Object types',
    'LC__MODULE__BECON_OC__HOOKS'                                   => 'Triggers',
    'LC__MODULE__BECON_OC__TRIGGERS'                                => 'Trigger',
    'LC__MODULE__BECON_OC__ALL_OBJECTTYPES'                         => 'All',
    'LC__MODULE__BECON_OC__CONFIG__IPV4'                            => 'IPv4 address of current single host address entry. If not in single hostaddress view, the primary ip address will be used.',
    'LC__MODULE__BECON_OC__CONFIG__HOSTNAME'                        => 'Hostname of current single host address entry. If not in single hostaddress view, hostname of primary entry will be used.',
    'LC__MODULE__BECON_OC__CONFIG__FQDN'                            => 'FQDN of the current single host address entry. If not in single hostaddress view, FQDN of primary entry will be used.',
    'LC__MODULE__BECON_OC__CONFIG__OBJID_SEL'                       => 'Object ID of selected IP list entry.',
    'LC__MODULE__BECON_OC__CONFIG__OBJTITLE_SEL'                    => 'Title of selected IP list entry.',
    'LC__MODULE__BECON_OC__CONFIG__OBJID'                           => 'Object ID of current object.',
    'LC__MODULE__BECON_OC__CONFIG__OBJTITLE'                        => 'Title of current object.',
    'LC__MODULE__BECON_OC__CONFIG__CATGID'                          => 'Categorie ID of current global category.',
    'LC__MODULE__BECON_OC__CONFIG__CATSID'                          => 'Categorie ID of current specific category.',
    'LC__MODULE__BECON_OC__CONFIG__CATCID'                          => 'Categorie ID of current custom category.',
    'LC__MODULE__BECON_OC__CONFIG__CATEID'                          => 'ID of current category entry (only multivalue categories)',
    'LC__MODULE__BECON_OC__TRIGGERS__HEADLINE'                      => 'Triggers',
    'LC__MODULE__BECON_OC__TRIGGERS__DESCRIPTION'                   => '',
    'LC__MODULE__BECON_OC__TRIGGER_NAME'                            => 'Name',
    'LC__MODULE__BECON_OC__TRIGGER_TOKEN'                             => 'TOKEN',
    'LC__MODULE__BECON_OC__TRIGGERS_TARGET'                         => 'Target',
    'LC__MODULE__BECON_OC__TRIGGERS_TYPE'                           => 'Call type',
    'LC__MODULE__BECON_OC__TRIGGERS_PARAMETER'                      => 'URL parameter',
    'LC__MODULE__BECON_OC__TRIGGERS_TYPE__HTTP'                     => 'HTTP/HTTPS',
    'LC__MODULE__BECON_OC__TRIGGERS_TYPE__SHELL'                    => 'SHELL',
    'LC__MODULE__BECON_OC__CONFIG_TRIGGER_SELECT'                   => 'Trigger',
    'LC__MODULE__BECON_OC__PLEASE_SELECT_TRIGGER'                   => 'Please select Trigger',
    'LC__MODULE__BECON_OC__TRIGGERS_MENUICON'                       => 'Menu icon',
    'LC__MODULE__BECON_OC__TRIGGERS_ICON_UPLOAD'                    => 'Upload new menu icon',
    'LC__AUTH__BECON_OC_EXCEPTION__MISSING_RIGHT_FOR_CALLING_SCRIPT'=> 'You are not allowed to execute this script',
    'LC__MODULE__BECON_OC__SELECT_TRIGGERS'                         => 'Please select Trigger...',
    'LC__MODULE__BECON_OC__EXECUTE_TRIGGER'                         => 'Execute trigger',
    'LC__MODULE__BECON_OC__TRIGGERS_MENUENTRY'                      => 'Menu entry',
    'LC__MODULE__BECON_OC__TRIGGERS_OPTIONS'                        => 'Options',
    'LC__MODULE__BECON_OC__CONFIG__TRIGGER_NEW_OPTION'              => 'New option',
    'LC__MODULE__BECON_OC__CONFIG__TRIGGER_CURL_OPTIONS'            => 'Documentation of cURL options',
    'LC__MODULE__BECON_OC__CONFIG__DESCRIPTION'                     => 'A list of values is replaced as a comma-separated string by default. Placeholders in square brackets are replaced with a JSON representation of an array, even for single values.',
    'LC__MODULE__BECON_OC__CONFIG__PLACEHOLDER'                     => 'Placeholder',
    'LC__MODULE__BECON_OC__CONFIG__PLACEHOLDER_ARR'                 => 'Placeholder (Array)',
    'LC__MODULE__BECON_OC__CONFIG__PLACEHOLDER_DESC'                => 'Description',
    'LC__MODULE__BECON_OC__CONFIG__TRIGGER_SELECT_OPTION'           => 'Please select an option',
];