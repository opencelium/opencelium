<?php
/**
 * i-doit
 *
 * "becon_OC" Module language file.
 *
 * @package     Modules
 * @subpackage  becon_OpenCelium
 * @author      Kai Schubert-Altmann <kai.schubert-altmann@becon.de>
 * @version     1.0
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */

return [
    'LC__MODULE__BECON_OC'                                          => 'OpenCelium',
    'LC__MODULE__BECON_OC__CONFIGURATION'                           => 'Menü-Konfiguration',
    'LC__MODULE__BECON_OC__CALL_SCRIPT'                             => 'Skripte aufrufen',
    'LC__MODULE__BECON_OC__CONFIG__HEADLINE'                        => 'Menü-Konfiguration',
    'LC__MODULE__BECON_OC__CONFIG__DESCRIPTION'                     => 'Bitte geben Sie an, bei welchen Objekttypen und/oder Kategorien die Triggers angezeigt werden sollen:',
    'LC__MODULE__BECON_OC__CONFIG__TRIGGER_PLACEHOLDER'             => 'Folgende Platzhalter können verwendet werden:',
    'LC__MODULE__BECON_OC__CONFIG_SAVE_SUCCESS'                     => 'Konfiguration erfolgreich gespeichert.',
    'LC__MODULE__BECON_OC__CONFIG_SAVE_ERROR'                       => 'Konfiguration konnte nicht gespeichert werden.',
    'LC__MODULE__BECON_OC__CONFIG_TRIGGER_NAME'                     => 'Name',
    'LC__MODULE__BECON_OC__CONFIG_TRIGGER_TOKEN'                    => 'Token',
    'LC__MODULE__BECON_OC__CONFIG_ACTION'                           => 'Aktion',
    'LC__MODULE__BECON_OC__TOKEN_NOT_CONFIGURED'                    => 'Trigger-Token ist nicht konfiguriert',
    'LC__MODULE__BECON_OC__URL_NOT_AVAILABLE'                       => 'Trigger-Url kann nicht aufgerufen werden. Eventuell ist der Server nicht erreichbar oder die DNS-Auflösung ist fehlgeschlagen.',
    'LC__MODULE__BECON_OC__URL_NOT_OK'                              => 'Server antwortet mit Code',
    'LC__MODULE__BECON_OC__NO_CONFIGURATION_SELECTED'               => 'Keine Trigger-Konfiguration ausgewählt.',
    'LC__MODULE__BECON_OC__HOOKS_DEFINED'                           => 'Trigger definiert',
    'LC__MODULE__BECON_OC__CONFIG_ADD_HOOK'                         => 'Neuer Trigger',
    'LC__MODULE__BECON_OC__OBJECT_TYPES'                            => 'Objekttypen',
    'LC__MODULE__BECON_OC__HOOKS'                                   => 'Triggers',
    'LC__MODULE__BECON_OC__TRIGGERS'                                => 'Trigger',
    'LC__MODULE__BECON_OC__ALL_OBJECTTYPES'                         => 'Alle',
    'LC__MODULE__BECON_OC__CONFIG__IPV4'                            => 'IPv4-Adresse des aktuellen Hostadressen- oder IP-Listen-Eintrags. Wenn man nicht in der Hostadressen-Einzelansicht ist, wird die primäre IP-Adresse benutzt.',
    'LC__MODULE__BECON_OC__CONFIG__HOSTNAME'                        => 'Hostname des aktuell besuchten Hostadressen- oder IP-Listen-Eintrags. Wenn man nicht in der Hostadressen-Einzelansicht ist, wird der Hostname des primären Eintrags benutzt.',
    'LC__MODULE__BECON_OC__CONFIG__FQDN'                            => 'FQDN des aktuell besuchten Hostadressen-Eintrags. Wenn man nicht in der Hostadressen-Einzelansicht ist, wird der FQDN des primären Eintrags benutzt.',
    'LC__MODULE__BECON_OC__CONFIG__OBJID_SEL'                       => 'Objekt ID des ausgewählten IP-Listen-Eintrags.',
    'LC__MODULE__BECON_OC__CONFIG__OBJTITLE_SEL'                    => 'Titel des ausgewählten IP-Listen-Eintrags.',
    'LC__MODULE__BECON_OC__CONFIG__OBJID'                           => 'Objekt ID des aktuellen Objektes.',
    'LC__MODULE__BECON_OC__CONFIG__OBJTITLE'                        => 'Titel des aktuellen Objektes.',
    'LC__MODULE__BECON_OC__CONFIG__CATGID'                          => 'Kategorie ID der aktuellen globalen Kategorie.',
    'LC__MODULE__BECON_OC__CONFIG__CATSID'                          => 'Kategorie ID der aktuellen spezifischen Kategorie.',
    'LC__MODULE__BECON_OC__CONFIG__CATCID'                          => 'Kategorie ID der aktuellen benutzerdefinierten Kategorie.',
    'LC__MODULE__BECON_OC__CONFIG__CATEID'                          => 'ID des aktuellen Kategorieeintrags (nur bei Multivalue-Kategorien)',
    'LC__MODULE__BECON_OC__TRIGGERS__HEADLINE'                      => 'Trigger-Konfiguration',
    'LC__MODULE__BECON_OC__TRIGGERS__DESCRIPTION'                   => '',
    'LC__MODULE__BECON_OC__TRIGGERS_NAME'                           => 'Name',
    'LC__MODULE__BECON_OC__TRIGGERS_TOKEN'                            => 'Token',
    'LC__MODULE__BECON_OC__TRIGGERS_TARGET'                         => 'Ziel',
    'LC__MODULE__BECON_OC__TRIGGERS_TYPE'                           => 'Aufruf-Art',
    'LC__MODULE__BECON_OC__TRIGGERS_PARAMETER'                      => 'URL-Parameter',
    'LC__MODULE__BECON_OC__TRIGGERS_TYPE__HTTP'                      => 'HTTP/HTTPS',
    'LC__MODULE__BECON_OC__TRIGGERS_TYPE__SHELL'                    => 'SHELL',
    'LC__MODULE__BECON_OC__CONFIG_TRIGGER_SELECT'                   => 'Trigger',
    'LC__MODULE__BECON_OC__PLEASE_SELECT_TRIGGER'                   => 'Bitte Trigger auswählen',
    'LC__MODULE__BECON_OC__TRIGGERS_MENUICON'                       => 'Menü-Icon',
    'LC__MODULE__BECON_OC__TRIGGERS_ICON_UPLOAD'                    => 'Neues Menü-Icon hochladen',
    'LC__AUTH__BECON_OC_EXCEPTION__MISSING_RIGHT_FOR_CALLING_SCRIPT'=> 'Es ist Ihnen nicht erlaubt, dieses Skript aufzurufen',
    'LC__MODULE__BECON_OC__SELECT_TRIGGERS'                         => 'Bitte Trigger auswählen ...',
    'LC__MODULE__BECON_OC__EXECUTE_TRIGGER'                         => 'Trigger aufrufen',
    'LC__MODULE__BECON_OC__TRIGGERS_MENUENTRY'                      => 'Menüpunkt',
    'LC__MODULE__BECON_OC__TRIGGERS_OPTIONS'                        => 'Optionen',
    'LC__MODULE__BECON_OC__CONFIG__TRIGGER_NEW_OPTION'              => 'Neue Option',
    'LC__MODULE__BECON_OC__CONFIG__TRIGGER_CURL_OPTIONS'            => 'Beschreibung cURL-Optionen',
    'LC__MODULE__BECON_OC__CONFIG__DESCRIPTION'                     => 'Eine Liste von Werten wird standardmäßig als kommaseparierter String ersetzt. Platzhalter in eckigen Klammern werden durch eine JSON-Repräsentation eines Arrays ersetzt, auch bei Einzelwerten.',
    'LC__MODULE__BECON_OC__CONFIG__PLACEHOLDER'                     => 'Platzhalter',
    'LC__MODULE__BECON_OC__CONFIG__PLACEHOLDER_ARR'                 => 'Platzhalter (Array)',
    'LC__MODULE__BECON_OC__CONFIG__PLACEHOLDER_DESC'                => 'Beschreibung',
    'LC__MODULE__BECON_OC__CONFIG__TRIGGER_SELECT_OPTION'           => 'Bitte eine Option auswählen',
];
