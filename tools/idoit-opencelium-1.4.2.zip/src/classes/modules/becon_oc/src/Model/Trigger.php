<?php

namespace idoit\Module\Beconoc\Model;

use idoit\Model\Dao\Base;
use isys_cmdb_dao as DaoCmdb;
use isys_format_json as JSON;

/**
 * i-doit Trigger Model
 *
 * @package     Modules
 * @subpackage  Becon_Oc
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */
class Trigger extends Base
{
    /**
     * Fields of "isys_becon_oc_trigger".
     */
    const FIELDS = [
        'isys_becon_oc_trigger__id'               => 'id',
        'isys_becon_oc_trigger__name'             => 'name',
        'isys_becon_oc_trigger__token'            => 'token',
        'isys_becon_oc_trigger__type'             => 'type',
        'isys_becon_oc_trigger__target'           => 'target',
        'isys_becon_oc_trigger__parameter'        => 'parameter',
        'isys_becon_oc_trigger__options'          => 'options',
        'isys_becon_oc_trigger__icon'             => 'icon',
    ];

    /**
     * @param  int|array $id
     * @param  string    $tag
     *
     * @return \isys_component_dao_result
     * @throws \isys_exception_database
     */
    public function getTrigger($id = null)
    {
        $select = $this->selectImplode(self::FIELDS);

        $sql = 'SELECT ' . $select . ' 
            FROM isys_becon_oc_trigger';

        if ($id !== null) {
            if (!is_array($id)) {
                $id = [$id];
            }

            $sql .= ' WHERE isys_becon_oc_trigger__id ' . $this->prepare_in_condition($id);
        }


        return $this->retrieve($sql . ';');
    }

    /**
     * @param  int|array $id
     * @param  string    $tag
     *
     * @return \isys_component_dao_result
     * @throws \isys_exception_database
     */
    public function getTriggerByToken($token)
    {
        $select = $this->selectImplode(self::FIELDS);

        $sql = 'SELECT ' . $select . ' 
            FROM isys_becon_oc_trigger';

        if (!empty($token)) {
            $sql .= ' WHERE isys_becon_oc_trigger__token  = ' . $this->convert_sql_text($token);
        }

        $trigger = $this->retrieve($sql . ';')->get_row();

        if(!empty($trigger)){
            $trigger['options'] = empty($trigger['options'])?[]:json_decode($trigger['options'],true);
        }
        return $trigger;
    }

    /**
     * Method for retrieving all profiles.
     *
     * @return \isys_component_dao_result
     * @throws \isys_exception_database
     */
    public function getTriggers()
    {
        $select = $this->selectImplode(self::FIELDS);

        $sql = 'SELECT ' . $select . ' 
            FROM isys_becon_oc_trigger';

        return $this->retrieve($sql);
    }

    /**
     * @param  integer $id
     * @param  array   $data
     *
     * @return boolean
     * @throws \isys_exception_dao
     */
    public function saveTrigger($id, array $data)
    {
        $fields = [];

        foreach ($data as $key => $value) {
            $field = 'isys_becon_oc_trigger__' . $key;

            if (!self::FIELDS[$field]) {
                continue;
            }
            $value = $this->convert_sql_text($value);

            $fields[] = $field . ' = ' . $value;
        }

        if (!count($fields)) {
            return true;
        }

        if ($id === null) {
            $sql = 'INSERT INTO isys_becon_oc_trigger SET ' . implode(', ', $fields) . ';';
        } else {
            $sql = 'UPDATE isys_becon_oc_trigger 
                SET ' . implode(', ', $fields) . ' 
                WHERE isys_becon_oc_trigger__id = ' . $this->convert_sql_id($id) . ';';
        }

        $this->update($sql) && $this->apply_update();

        // Get the newly created id.
        if ($id === null) {
            $id = DaoCmdb::instance($this->m_db)->get_last_id_from_table('isys_becon_oc_trigger');
        }

        return $id;
    }

    /**
     *
     * @param  array|integer $ids
     *
     * @return \isys_component_dao_result
     * @throws \isys_exception_database
     */
    public function deleteTriggers($ids)
    {
        $ids = (array)$ids;

        $configModel = new Config($this->m_db);

        $configs = $configModel->getConfigs();
        foreach($configs as $config){
            $hooks = json_decode($config['hooks'],true);
            $hooksNew = [];
            foreach($hooks as $hook){
                if(!in_array($hook['trigger_id'],$ids)){
                    $hooksNew[] = $hook;
                }
            }
            if(count($hooks) != count($hooksNew)){
                if(count($hooksNew) == 0){
                    $configModel->deleteConfigs($config['id']);
                } else {
                    $configModel->saveConfig($config['id'],['hooks'=>json_encode($hooksNew)]);
                }
            }
        }

        
        $sql = 'DELETE FROM isys_becon_oc_trigger WHERE isys_becon_oc_trigger__id ' . $this->prepare_in_condition($ids) . ';';

        return $this->update($sql) && $this->apply_update();
    }

    public static function getCurlOptionsArr(){
        return [
            'boolean' => ["CURLOPT_AUTOREFERER","CURLOPT_COOKIESESSION","CURLOPT_CERTINFO","CURLOPT_CONNECT_ONLY","CURLOPT_CRLF","CURLOPT_DISALLOW_USERNAME_IN_URL","CURLOPT_DNS_SHUFFLE_ADDRESSES","CURLOPT_HAPROXYPROTOCOL","CURLOPT_SSH_COMPRESSION","CURLOPT_DNS_USE_GLOBAL_CACHE","CURLOPT_FAILONERROR","CURLOPT_SSL_FALSESTART","CURLOPT_FILETIME","CURLOPT_FOLLOWLOCATION","CURLOPT_FORBID_REUSE","CURLOPT_FRESH_CONNECT","CURLOPT_FTP_USE_EPRT","CURLOPT_FTP_USE_EPSV","CURLOPT_FTP_CREATE_MISSING_DIRS","CURLOPT_FTPAPPEND","CURLOPT_TCP_NODELAY","CURLOPT_FTPASCII","CURLOPT_FTPLISTONLY","CURLOPT_HEADER","CURLINFO_HEADER_OUT","CURLOPT_HTTP09_ALLOWED","CURLOPT_HTTPGET","CURLOPT_HTTPPROXYTUNNEL","CURLOPT_HTTP_CONTENT_DECODING","CURLOPT_KEEP_SENDING_ON_ERROR","CURLOPT_MUTE","CURLOPT_NETRC","CURLOPT_NOBODY","CURLOPT_NOPROGRESS","CURLOPT_NOSIGNAL","CURLOPT_PATH_AS_IS","CURLOPT_PIPEWAIT","CURLOPT_POST","CURLOPT_PUT","CURLOPT_RETURNTRANSFER","CURLOPT_SASL_IR","CURLOPT_SSL_ENABLE_ALPN","CURLOPT_SSL_ENABLE_NPN","CURLOPT_SSL_VERIFYPEER","CURLOPT_SSL_VERIFYSTATUS","CURLOPT_PROXY_SSL_VERIFYPEER","CURLOPT_SAFE_UPLOAD","CURLOPT_SUPPRESS_CONNECT_HEADERS","CURLOPT_TCP_FASTOPEN","CURLOPT_TFTP_NO_OPTIONS","CURLOPT_TRANSFERTEXT","CURLOPT_UNRESTRICTED_AUTH","CURLOPT_UPLOAD","CURLOPT_VERBOSE"],
            'integer' => ["CURLOPT_BUFFERSIZE","CURLOPT_CONNECTTIMEOUT","CURLOPT_CONNECTTIMEOUT_MS","CURLOPT_DNS_CACHE_TIMEOUT","CURLOPT_EXPECT_100_TIMEOUT_MS","CURLOPT_HAPPY_EYEBALLS_TIMEOUT_MS","CURLOPT_FTPSSLAUTH","CURLOPT_HEADEROPT","CURLOPT_HTTP_VERSION","CURLOPT_HTTPAUTH","CURLOPT_INFILESIZE","CURLOPT_LOW_SPEED_LIMIT","CURLOPT_LOW_SPEED_TIME","CURLOPT_MAXCONNECTS","CURLOPT_MAXREDIRS","CURLOPT_PORT","CURLOPT_POSTREDIR","CURLOPT_PROTOCOLS","CURLOPT_PROXYAUTH","CURLOPT_PROXYPORT","CURLOPT_PROXYTYPE","CURLOPT_REDIR_PROTOCOLS","CURLOPT_RESUME_FROM","CURLOPT_SOCKS5_AUTH","CURLOPT_SSL_OPTIONS","CURLOPT_SSL_VERIFYHOST","CURLOPT_SSLVERSION","CURLOPT_PROXY_SSL_OPTIONS","CURLOPT_PROXY_SSL_VERIFYHOST","CURLOPT_PROXY_SSLVERSION","CURLOPT_STREAM_WEIGHT","CURLOPT_TCP_KEEPALIVE","CURLOPT_TCP_KEEPIDLE","CURLOPT_TCP_KEEPINTVL","CURLOPT_TIMECONDITION","CURLOPT_TIMEOUT","CURLOPT_TIMEOUT_MS","CURLOPT_TIMEVALUE","CURLOPT_TIMEVALUE_LARGE","CURLOPT_MAX_RECV_SPEED_LARGE","CURLOPT_MAX_SEND_SPEED_LARGE","CURLOPT_SSH_AUTH_TYPES","CURLOPT_IPRESOLVE","CURLOPT_FTP_FILEMETHOD"],
            'string' => ["CURLOPT_ABSTRACT_UNIX_SOCKET","CURLOPT_CAINFO","CURLOPT_CAPATH","CURLOPT_COOKIE","CURLOPT_COOKIEFILE","CURLOPT_COOKIEJAR","CURLOPT_COOKIELIST","CURLOPT_CUSTOMREQUEST","CURLOPT_DEFAULT_PROTOCOL","CURLOPT_DNS_INTERFACE","CURLOPT_DNS_LOCAL_IP4","CURLOPT_DNS_LOCAL_IP6","CURLOPT_EGDSOCKET","CURLOPT_ENCODING","CURLOPT_FTPPORT","CURLOPT_INTERFACE","CURLOPT_KEYPASSWD","CURLOPT_KRB4LEVEL","CURLOPT_LOGIN_OPTIONS","CURLOPT_PINNEDPUBLICKEY","CURLOPT_POSTFIELDS","CURLOPT_PRIVATE","CURLOPT_PRE_PROXY","CURLOPT_PROXY","CURLOPT_PROXY_SERVICE_NAME","CURLOPT_PROXY_CAINFO","CURLOPT_PROXY_CAPATH","CURLOPT_PROXY_CRLFILE","CURLOPT_PROXY_KEYPASSWD","CURLOPT_PROXY_PINNEDPUBLICKEY","CURLOPT_PROXY_SSLCERT","CURLOPT_PROXY_SSLCERTTYPE","CURLOPT_PROXY_SSL_CIPHER_LIST","CURLOPT_PROXY_TLS13_CIPHERS","CURLOPT_PROXY_SSLKEY","CURLOPT_PROXY_SSLKEYTYPE","CURLOPT_PROXY_TLSAUTH_PASSWORD","CURLOPT_PROXY_TLSAUTH_TYPE","CURLOPT_PROXY_TLSAUTH_USERNAME","CURLOPT_PROXYUSERPWD","CURLOPT_RANDOM_FILE","CURLOPT_RANGE","CURLOPT_REFERER","CURLOPT_SERVICE_NAME","CURLOPT_SSH_HOST_PUBLIC_KEY_MD5","CURLOPT_SSH_PUBLIC_KEYFILE","CURLOPT_SSH_PRIVATE_KEYFILE","CURLOPT_SSL_CIPHER_LIST","CURLOPT_SSLCERT","CURLOPT_SSLCERTPASSWD","CURLOPT_SSLCERTTYPE","CURLOPT_SSLENGINE","CURLOPT_SSLENGINE_DEFAULT","CURLOPT_SSLKEY","CURLOPT_SSLKEYPASSWD","CURLOPT_SSLKEYTYPE","CURLOPT_TLS13_CIPHERS","CURLOPT_UNIX_SOCKET_PATH","CURLOPT_URL","CURLOPT_USERAGENT","CURLOPT_USERNAME","CURLOPT_PASSWORD","CURLOPT_USERPWD","CURLOPT_XOAUTH2_BEARER"],
            'array' => ["CURLOPT_CONNECT_TO","CURLOPT_HTTP200ALIASES","CURLOPT_HTTPHEADER","CURLOPT_POSTQUOTE","CURLOPT_PROXYHEADER","CURLOPT_QUOTE","CURLOPT_RESOLVE"]
        ];
    }

    public static function getCurlOptionsAsHtml($selectedValue = ""){
        $html = '';
        $curlOptions = self::getCurlOptionsArr();
        foreach($curlOptions as $type=>$values){
            $html .= '<optgroup label="Datatype '.ucfirst($type).'">';
            foreach($values as $value){
                if(defined($value)){
                    $html .= '<option value="'.$value.'"'.($value == $selectedValue?' selected="selected"':'').'>'.$value.'</option>';
                }
            }
            $html .= '</optgroup>';
        }
        return $html;
    }

    public static function getVerifiedCurlOptionValue($const,$val){
        $return = [
            'type' =>'not_supported',
            'error'=>false
        ];
        $curlOptions = self::getCurlOptionsArr();
        if(defined($const)){
            $return['type'] = 'unknown';
            if(in_array($const,$curlOptions['boolean'])){
                $return['type'] = 'boolean';
                if(empty($val) || $val == 'false'){
                    $return['value'] = false;
                } else {
                    $return['value'] = true;
                }
            } elseif(in_array($const,$curlOptions['integer'])){
                $return['type'] = 'integer';
                if(is_numeric($val)){
                    $return['value'] = intval($val);
                } else {
                    if(str_starts_with($val,'CURL') && defined($val)){
                        $return['value'] = constant($val);
                    } else {
                        $return['error'] = true;    
                    }
                }
            } elseif(in_array($const,$curlOptions['string'])){
                $return['type'] = 'string';
                $return['value'] = $val;
            } elseif(in_array($const,$curlOptions['array'])){
                $return['type'] = 'array';
                $decodedVal = json_decode($val,true);
                if(is_array($decodedVal)){
                    $return['value'] = $decodedVal;
                } else {
                    $return['error'] = true;
                }
            }
        }
        return $return;
    }
}
