<?php

namespace idoit\Module\Beconoc\Model;

use idoit\Model\Dao\Base;
use isys_cmdb_dao as DaoCmdb;
use isys_format_json as JSON;

/**
 * i-doit Config Model
 *
 * @package     Modules
 * @subpackage  Becon_Oc
 * @copyright   becon GmbH
 * @license     http://www.i-doit.com/license
 */
class Config extends Base
{
    /**
     * Fields of "isys_becon_oc_config".
     */
    const FIELDS = [
        'isys_becon_oc_config__id'                       => 'id',
        'isys_becon_oc_config__object_types'             => 'object_types',
        'isys_becon_oc_config__categories'               => 'categories',
        'isys_becon_oc_config__categories_s'             => 'categories_s',
        'isys_becon_oc_config__categories_c'             => 'categories_c',
        'isys_becon_oc_config__hooks'                    => 'hooks',
    ];

    /**
     * @param  int|array $id
     * @param  string    $tag
     *
     * @return \isys_component_dao_result
     * @throws \isys_exception_database
     */
    public function getConfig($id = null)
    {
        $select = $this->selectImplode(self::FIELDS);

        $sql = 'SELECT ' . $select . ' 
            FROM isys_becon_oc_config';

        if ($id !== null) {
            if (!is_array($id)) {
                $id = [$id];
            }

            $sql .= ' WHERE isys_becon_oc_config__id ' . $this->prepare_in_condition($id);
        }


        return $this->retrieve($sql . ';');
    }

    /**
     * Method for retrieving all profiles.
     *
     * @return \isys_component_dao_result
     * @throws \isys_exception_database
     */
    public function getConfigs()
    {
        $select = $this->selectImplode(self::FIELDS);

        $sql = 'SELECT ' . $select . ' 
            FROM isys_becon_oc_config';

        return $this->retrieve($sql);
    }

    /**
     * @param  integer $id
     * @param  array   $data
     *
     * @return boolean
     * @throws \isys_exception_dao
     */
    public function saveConfig($id, array $data)
    {
        $fields = [];

        foreach ($data as $key => $value) {
            $field = 'isys_becon_oc_config__' . $key;

            if (!self::FIELDS[$field]) {
                continue;
            }
            $value = $this->convert_sql_text($value);

            $fields[] = $field . ' = ' . $value;
        }

        if (!count($fields)) {
            return true;
        }

        if ($id === null) {
            $sql = 'INSERT INTO isys_becon_oc_config SET ' . implode(', ', $fields) . ';';
        } else {
            $sql = 'UPDATE isys_becon_oc_config 
                SET ' . implode(', ', $fields) . ' 
                WHERE isys_becon_oc_config__id = ' . $this->convert_sql_id($id) . ';';
        }

        $this->update($sql) && $this->apply_update();

        // Get the newly created id.
        if ($id === null) {
            $id = DaoCmdb::instance($this->m_db)->get_last_id_from_table('isys_becon_oc_config');
        }

        return $id;
    }

    /**
     *
     * @param  array|integer $ids
     *
     * @return \isys_component_dao_result
     * @throws \isys_exception_database
     */
    public function deleteConfigs($ids)
    {
        $ids = (array)$ids;

        $sql = 'DELETE FROM isys_becon_oc_config WHERE isys_becon_oc_config__id ' . $this->prepare_in_condition($ids) . ';';

        return $this->retrieve($sql);
    }
}
