<?php

namespace idoit\Module\Beconoc\SettingPage\Triggers;

use idoit\Module\Beconoc\Model\Trigger;
use idoit\Module\Beconoc\SettingPage\SettingPage;
use isys_cmdb_dao as DaoCmdb;
use isys_component_list as ComponentList;
use isys_component_template_navbar as ComponentNavbar;
use isys_helper_link as HelperLink;
use isys_module_becon_oc as ModuleBeconoc;
use isys_notify as Notify;
use isys_auth_becon_oc;
use isys_auth as Auth;

/**
 * Class OcConfiguration
 *
 * @package idoit\Module\Cmk2\SettingPage
 */
class Triggers extends SettingPage
{
    
    const ICONS_DIR = 'src/classes/modules/becon_oc/assets/images/icons';

    /**
     * @param  integer $navMode
     *
     * @return void
     */
    public function renderPage($navMode)
    {
        $triggerId = 0;

        if (isset($_POST['id']) && is_numeric($_POST['id'])) {
            $triggerId = (int)$_POST['id'];
        } elseif (isset($_POST['id']) && is_array($_POST['id'])) {
            $triggerId = $_POST['id'][0];
        }

        if (!is_numeric($triggerId) || !$triggerId) {
            $triggerId = null;
        }

        switch ($navMode) {
            case C__NAVMODE__DELETE:
                $this->deleteTriggers((array)$_POST['id']);

                // Display the list after deletion.
                $this->listTriggers();
                break;

            case C__NAVMODE__SAVE:
                $triggerId = $this->saveTrigger($triggerId, $_POST);
                if($triggerId){
                    Notify::success($this->language->get('LC__MODULE__BECON_OC__CONFIG_SAVE_SUCCESS'));
                } else {
                    Notify::warning($this->language->get('LC__MODULE__BECON_OC__CONFIG_SAVE_ERROR'));
                }
                // Display the list-view after creating/updating.
                $this->listTriggers();
                break;
            case C__NAVMODE__EDIT:
                $this->editTrigger($triggerId);
                break;
            case C__NAVMODE__NEW:
                $this->editTrigger(0);
                break;

            default:
                $this->listTriggers();
        }
    }

    /**
     * Method for deleting existing tags.
     *
     * @param  array $ids
     *
     * @throws \isys_exception_database
     */
    private function deleteTriggers(array $ids)
    {
        $triggerModel = new Trigger($this->database);

        if (count($ids)) {
            $triggerModel->deleteTriggers($ids);
        } else {
            Notify::warning($this->language->get('LC__MODULE__BECON_OC__NO_CONFIGURATION_SELECTED'));
        }
    }

    /**
     * @param  integer $triggerId
     * @param  array   $data
     *
     * @return boolean
     * @throws \isys_exception_dao
     */
    private function saveTrigger($triggerId, array $data)
    {
        $options = [];
        foreach($_POST['C__BECON_OC__TRIGGERS__OPTIONS_NAME'] as $index=>$name){
            if(!empty($name)){
                $verifiedCurlOption = Trigger::getVerifiedCurlOptionValue($name,$_POST['C__BECON_OC__TRIGGERS__OPTIONS_VALUE'][$index]);
                if($verifiedCurlOption['type'] == 'not_supported'){
                    Notify::warning($name." is unknown or not supported",['sticky' => true]);
                } elseif($verifiedCurlOption['error']){
                    Notify::warning($name." has to be of type ".$verifiedCurlOption['type'],['sticky' => true]);
                } else {
                    $options[] = [
                        'name' => $name,
                        'value' => $verifiedCurlOption['value']
                    ];
                }
            }
        }
        $triggerData = [
            'name'          => $_POST['C__BECON_OC__TRIGGERS__NAME'],
            'token'         => $_POST['C__BECON_OC__TRIGGERS__TOKEN'],
            'target'        => $_POST['C__BECON_OC__TRIGGERS__TARGET'],
            'type'          => $_POST['C__BECON_OC__TRIGGERS__TYPE'],
            'parameter'     => $_POST['C__BECON_OC__TRIGGERS__PARAMETER'],
            'options'       => json_encode($options),
            'icon'          => str_replace(self::ICONS_DIR.'/','',$_POST['C__BECON_OC__TRIGGERS__ICON']),
        ];

        $triggerModel = new Trigger($this->database);

        return $triggerModel->saveTrigger($triggerId, $triggerData);
    }

    /**
     * @param  integer $triggerId
     *
     * @throws \isys_exception_database
     */
    private function editTrigger($triggerId)
    {

        global $g_absdir;


        $triggerModel = new Trigger($this->database);

        $name = '';
        $token = '';
        $target = '';
        $type = ModuleBeconoc::TYPE_HTTP;
        $parameter = '';
        //$icon = 'src/classes/modules/becon_oc/assets/images/icons/link_go.png';
        $icon = 'OpenCelium.png';
        if ($triggerId > 0) {
            $triggerData = $triggerModel->getTrigger($triggerId)->get_row();

            $name = $triggerData['name'] ?? '';
            $token = $triggerData['token'] ?? '';
            $target = $triggerData['target'] ?? '';
            $type = $triggerData['type'] ?? '';
            $parameter = $triggerData['parameter'] ?? '';
            $options = json_decode($triggerData['options'],true) ?? [];
            foreach($options as &$option){
                if(is_array($option['value'])){
                    $option['value'] = htmlentities(json_encode($option['value']));
                }
                $option['html'] = Trigger::getCurlOptionsAsHtml($option['name']);
            }
            $icon = $triggerData['icon'] ?? 'OpenCelium.png';
        }


        $l_triggerMenuIcons = [];
        foreach ([self::ICONS_DIR] as $folder) {
            $iconFolder = rtrim( $g_absdir , '/') . '/' . $folder;
            if (file_exists($iconFolder) && is_dir($iconFolder)) {
                $l_directory = dir($iconFolder);
                while ($l_file = $l_directory->read()) {
                    if (strpos($l_file, '.') !== 0) {
                        $l_triggerMenuIcons[$folder . '/' . $l_file] = $l_file;
                    }
                }
                $l_directory->close();
            }
        }

        $triggerMenuIconArr = [];
        if (!empty($l_triggerMenuIcons)) {
            ksort($l_triggerMenuIcons);
            $triggerMenuIconArr["p_strValue"] = self::ICONS_DIR.'/'.$icon;
            $triggerMenuIconArr["p_strSelectedID"] = self::ICONS_DIR.'/'.$icon;
            $triggerMenuIconArr["p_arData"] = $l_triggerMenuIcons;
        }


        if(empty($token)){
            $token = ModuleBeconoc::generate_string();
        }
        

        $rules = [
            'C__BECON_OC__TRIGGERS__NAME' => [
                'p_strValue' => $name,
            ],
            'C__BECON_OC__TRIGGERS__TARGET' => [
                'p_strValue' => $target,
            ],
            'C__BECON_OC__TRIGGERS__PARAMETER' => [
                'p_strValue' => $parameter,
            ],
            'C__BECON_OC__TRIGGERS__TYPE' => [
                'p_arData'        => [
                    ModuleBeconoc::TYPE_HTTP => 'LC__MODULE__BECON_OC__TRIGGERS_TYPE__HTTP',
                    ModuleBeconoc::TYPE_SHELL => 'LC__MODULE__BECON_OC__TRIGGERS_TYPE__SHELL',
                ],
                'p_strClass'      => 'input-small',
                'p_bDbFieldNN'    => true,
                'p_strSelectedID' => $type
            ],
            'C__BECON_OC__TRIGGERS__ICON' => $triggerMenuIconArr
        ];

        $hideOptionsRow = ($type != ModuleBeconoc::TYPE_HTTP);
        $curlOptions = Trigger::getCurlOptionsAsHtml();
        $this->template->activate_editmode()
            ->assign('id', $triggerId)
            ->assign('idToken',$token)
            ->assign('triggerMenuIcons',$l_triggerMenuIcons)
            ->assign('triggerMenuIcon',self::ICONS_DIR.'/'.$icon)
            ->assign('options',$options)
            ->assign('curlOptions',$curlOptions)
            ->assign('hideOptionsRow',$hideOptionsRow)
            ->smarty_tom_add_rules('tom.content.bottom.content', $rules)
            ->include_template('contentbottomcontent', ModuleBeconoc::getPath() . 'templates/triggers_form.tpl');

        ComponentNavbar::getInstance()
            ->set_save_mode('formsubmit')
            ->set_active(true, C__NAVBAR_BUTTON__SAVE)
            ->set_active(true, C__NAVBAR_BUTTON__CANCEL);
    }

    /**
     * Method for displaying the tag list.
     *
     * @throws \isys_exception_database
     */
    private function listTriggers()
    {
        global $index_includes;

        $isAllowedToEdit = isys_auth_becon_oc::instance()->is_allowed_to(Auth::EDIT, 'becon_oc_triggers');

        $triggerModel = new Trigger($this->database);

        $l_url_params = $_GET;
        $l_url_params[C__GET__NAVMODE] = C__NAVMODE__EDIT;
        unset($l_url_params[C__GET__MAIN_MENU__NAVIGATION_ID], $l_url_params['id']);

        $headers = [
            'id'        => 'ID',
            'icon'      => 'LC__MODULE__BECON_OC__TRIGGERS_MENUENTRY',
            'name'      => 'LC__MODULE__BECON_OC__TRIGGERS_NAME',
            'token'     => 'LC__MODULE__BECON_OC__TRIGGERS_TOKEN',
            'type'      => 'LC__MODULE__BECON_OC__TRIGGERS_TYPE',
            'target'    => 'LC__MODULE__BECON_OC__TRIGGERS_TARGET',
            'parameter' => 'LC__MODULE__BECON_OC__TRIGGERS_PARAMETER',
        ];

        $triggersResult = $triggerModel->getTriggers();
        $triggersCount = count($triggersResult);

        $triggerList = new ComponentList(null, $triggersResult);

        $triggerList->config($headers, '', '[{id}]');

        $triggerList->set_row_modifier($this);

        if ($triggerList->createTempTable()) {
            $this->template->assign('list', $triggerList->getTempTableHtml());
        }


        ComponentNavbar::getInstance()
            ->set_active($isAllowedToEdit, C__NAVBAR_BUTTON__NEW)
            ->set_active($isAllowedToEdit && ($triggersCount > 0), C__NAVBAR_BUTTON__EDIT)
            ->set_active($isAllowedToEdit && ($triggersCount > 0), C__NAVBAR_BUTTON__DELETE)
            ->set_visible(true, C__NAVBAR_BUTTON__NEW)
            ->set_visible(true, C__NAVBAR_BUTTON__EDIT)
            ->set_visible(true, C__NAVBAR_BUTTON__DELETE);

        $this->template
            ->smarty_tom_add_rule('tom.content.navbar.cRecStatus.p_bInvisible=1')
            ->include_template('contentbottomcontent', ModuleBeconoc::getPath() . 'templates/list.tpl');
    }

    /**
     * @param $p_row
     */
    public function modify_row(&$p_row)
    {
        $dao = DaoCmdb::instance($this->database);
        if($p_row['type'] == ModuleBeconoc::TYPE_HTTP){
            $p_row['type'] = 'LC__MODULE__BECON_OC__TRIGGERS_TYPE__HTTP';
        } else {
            $p_row['type'] = 'LC__MODULE__BECON_OC__TRIGGERS_TYPE__SHELL';
        }
        $p_row['icon'] = '<img src="'.self::ICONS_DIR.'/'.$p_row['icon'].'" style="vertical-align:text-bottom;"/> '.ModuleBeconoc::getGroupNameByImage($p_row['icon']);
/*
        if (!empty($p_row['object_types'])) {
            $objTypeIds = explode(",",$p_row['object_types']);
            $object_types = $dao->get_objtype($objTypeIds);
            $objTypeNames = [];
            while ($row = $object_types->get_row()) {
                $objTypeNames[] = $this->language->get($row['isys_obj_type__title']);
            }
            $p_row['object_types'] = implode(", ",$objTypeNames);
        } else {
            $p_row['object_types'] = '<i>'.$this->language->get('LC__MODULE__BECON_OC__ALL_OBJECTTYPES').'</i>';
        }
        if (!empty($p_row['categories'])) {
            $categoryIds = explode(",",$p_row['categories']);
            $categoryNames = [];
            foreach($categoryIds as $categoryId) {
                $catg = $dao->get_all_catg($categoryId)->get_row();
                $categoryNames[] = $this->language->get($catg['isysgui_catg__title']);
            }

            $p_row['categories'] = implode(", ",$categoryNames);
        }

        if (!empty($p_row['categories_s'])) {
            $categoryIds = explode(",",$p_row['categories_s']);
            $categoryNames = [];
            foreach($categoryIds as $categoryId) {
                $catg = $dao->get_all_cats($categoryId)->get_row();
                $categoryNames[] = $this->language->get($catg['isysgui_cats__title']);
            }

            $p_row['categories_s'] = implode(", ",$categoryNames);
        }

        $hooks = json_decode($p_row['hooks'],true);

        $p_row['hooks'] = $this->language->get('LC__MODULE__BECON_OC__HOOKS_DEFINED').': '.count($hooks);
*/
    }

}
