<?php

namespace idoit\Module\Beconoc\SettingPage;

/**
 * Interface SettingPageInterface.
 *
 * @package idoit\Module\Beconoc\SettingPage
 */
interface SettingPageInterface
{
    /**
     * @param integer $navMode
     *
     * @return void
     */
    public function renderPage($navMode);

    /**
     * @param  string $function
     * @param  array  $postData
     *
     * @return array|mixed
     */
    public function processAjax($function, array $postData);
}
