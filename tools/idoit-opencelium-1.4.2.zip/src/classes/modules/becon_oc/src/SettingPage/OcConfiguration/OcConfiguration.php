<?php

namespace idoit\Module\Beconoc\SettingPage\OcConfiguration;

use idoit\Module\Beconoc\Model\Config;
use idoit\Module\Beconoc\Model\Trigger;
use idoit\Module\Beconoc\SettingPage\SettingPage;
use isys_cmdb_dao as DaoCmdb;
use isys_component_list as ComponentList;
use isys_component_template_navbar as ComponentNavbar;
use isys_helper_link as HelperLink;
use isys_module_becon_oc as ModuleBeconoc;
use isys_notify as Notify;
use isys_auth_becon_oc;
use isys_auth as Auth;

/**
 * Class OcConfiguration
 *
 * @package idoit\Module\Cmk2\SettingPage
 */
class OcConfiguration extends SettingPage
{
    /**
     * @param  integer $navMode
     *
     * @return void
     */
    public function renderPage($navMode)
    {
        $configId = 0;

        if (isset($_POST['id']) && is_numeric($_POST['id'])) {
            $configId = (int)$_POST['id'];
        } elseif (isset($_POST['id']) && is_array($_POST['id'])) {
            $configId = $_POST['id'][0];
        //} elseif (isset($_GET['id']) && is_numeric($_GET['id'])) {
        //    $configId = (int)$_GET['id'];
        }

        if (!is_numeric($configId) || !$configId) {
            $configId = null;
        }

        switch ($navMode) {
            case C__NAVMODE__DELETE:
                $this->deleteConfigs((array)$_POST['id']);

                // Display the list after deletion.
                $this->listConfigs();
                break;

            case C__NAVMODE__SAVE:
                $configId = $this->saveConfig($configId, $_POST);
                if($configId){
                    Notify::success($this->language->get('LC__MODULE__BECON_OC__CONFIG_SAVE_SUCCESS'));
                } else {
                    Notify::warning($this->language->get('LC__MODULE__BECON_OC__CONFIG_SAVE_ERROR'));
                }
                // Display the list-view after creating/updating.
                $this->listConfigs();
                break;
            case C__NAVMODE__EDIT:
                $this->editConfig($configId);
                break;
            case C__NAVMODE__NEW:
                $this->editConfig(0);
                break;

            default:
                
                $this->listConfigs();
        }
    }

    /**
     * Method for deleting existing tags.
     *
     * @param  array $ids
     *
     * @throws \isys_exception_database
     */
    private function deleteConfigs(array $ids)
    {
        $configModel = new Config($this->database);

        if (count($ids)) {
            $configModel->deleteConfigs($ids);
        } else {
            Notify::warning($this->language->get('LC__MODULE__BECON_OC__NO_CONFIGURATION_SELECTED'));
        }
    }

    /**
     * @param  integer $configId
     * @param  array   $data
     *
     * @return boolean
     * @throws \isys_exception_dao
     */
    private function saveConfig($configId, array $data)
    {
        $hooks = [];
        $triggerModel = new Trigger($this->database);

        for($i=0;$i<count($_POST['C__BECON_OC__CONFIGS__TRIGGER_NAME']);$i++){
            $hooks[] = [
                "name" => $_POST['C__BECON_OC__CONFIGS__TRIGGER_NAME'][$i],
                "trigger_id"  => $_POST['C__BECON_OC__CONFIGS__TRIGGER_ID'][$i],
            ];
            
        }

        $configData = [
            'object_types'              => $_POST['C__BECON_OC__CONFIGS__OBJECT_TYPES__selected_values'],
            'categories'              => $_POST['C__BECON_OC__CONFIGS__CATEGORIES_G__selected_values'],
            'categories_s'              => $_POST['C__BECON_OC__CONFIGS__CATEGORIES_S__selected_values'],
            'categories_c'              => $_POST['C__BECON_OC__CONFIGS__CATEGORIES_C__selected_values'],
            'hooks'                     => json_encode($hooks),
        ];

        $configModel = new Config($this->database);

        return $configModel->saveConfig($configId, $configData);
    }

    /**
     * @param  integer $configId
     *
     * @throws \isys_exception_database
     */
    private function editConfig($configId)
    {
        $configModel = new Config($this->database);
        $triggerModel = new Trigger($this->database);
        $dao = DaoCmdb::instance($this->database);
        $categories = $dao->get_all_categories();
        $object_types = $dao->get_objtype();

        $l_otypes = [];
        $l_categories_g = [];
        $l_categories_s = [];
        $selected_ot = [];
        $selected_catg = [];
        $selected_cats = [];
        $selected_catc = [];
        $hooks = [['name'=>'','trigger_id'=>'','image'=>'']];
        $triggers = $triggerModel->getTriggers()->__as_array();

        if ($configId > 0) {
            $configData = $configModel->getConfig($configId)->get_row();

            $selected_ot = explode(",",$configData['object_types'] ?? '');
            $selected_catg = explode(",",$configData['categories'] ?? '');
            $selected_cats = explode(",",$configData['categories_s'] ?? '');
            $selected_catc = explode(",",$configData['categories_c'] ?? '');
            $hooks = json_decode($configData['hooks'],true);
        }

        while ($row = $object_types->get_row()) {
            if (defined('C__OBJTYPE__GENERIC_TEMPLATE') && $row['isys_obj_type__id'] == C__OBJTYPE__GENERIC_TEMPLATE) {
                // Skip generic Template.
                continue;
            }

            $is_selected = in_array($row['isys_obj_type__id'],$selected_ot);

            $row['isys_obj_type__title'] = $this->language->get($row['isys_obj_type__title']);

            $l_otypes[$row['isys_obj_type__title']] = [
                'val' => $row['isys_obj_type__title'],
                'hid' => 0,
                'sel' => $is_selected,
                'id'  => $row['isys_obj_type__id']
            ];
        }

        ksort($l_otypes);

        $rules['C__BECON_OC__CONFIGS__OBJECT_TYPES']['p_arData'] = array_values($l_otypes);

        //Global categories
        foreach($categories[0] as $cat) {

            $is_selected = in_array($cat['id'],$selected_catg);

            $title = $this->language->get($cat['title']);

            $l_categories_g[$title] = [
                'val' => $title,
                'hid' => 0,
                'sel' => $is_selected,
                'id'  => $cat['id']
            ];
        }

        ksort($l_categories_g);

        $rules['C__BECON_OC__CONFIGS__CATEGORIES_G']['p_arData'] = array_values($l_categories_g);

        // Specific categories
        foreach($categories[1] as $cat) {

            $is_selected = in_array($cat['id'],$selected_cats);

            $title = $this->language->get($cat['title']);

            $l_categories_s[$title] = [
                'val' => $title,
                'hid' => 0,
                'sel' => $is_selected,
                'id'  => $cat['id']
            ];
        }

        ksort($l_categories_s);

        $rules['C__BECON_OC__CONFIGS__CATEGORIES_S']['p_arData'] = array_values($l_categories_s);

            
        // Custom categories
        foreach($categories[4] as $cat) {

            $is_selected = in_array($cat['id'],$selected_catc);

            $title = $this->language->get($cat['title']);

            $l_categories_c[$title] = [
                'val' => $title,
                'hid' => 0,
                'sel' => $is_selected,
                'id'  => $cat['id']
            ];
        }

        ksort($l_categories_c);

        $rules['C__BECON_OC__CONFIGS__CATEGORIES_C']['p_arData'] = array_values($l_categories_c);

            
        $this->template->activate_editmode()
            ->assign('id', $configId)
            ->assign('hooks',$hooks)
            ->assign('triggers',$triggers)
            ->smarty_tom_add_rules('tom.content.bottom.content', $rules)
            ->include_template('contentbottomcontent', ModuleBeconoc::getPath() . 'templates/menu_config_form.tpl');

        ComponentNavbar::getInstance()
            ->set_save_mode('formsubmit')
            ->set_active(true, C__NAVBAR_BUTTON__SAVE)
            ->set_active(true, C__NAVBAR_BUTTON__CANCEL);
    }

    /**
     * Method for displaying the tag list.
     *
     * @throws \isys_exception_database
     */
    private function listConfigs()
    {
        global $index_includes;
        
        $isAllowedToEdit = isys_auth_becon_oc::instance()->is_allowed_to(Auth::EDIT, 'becon_oc_config');
        $configModel = new Config($this->database);

        $l_url_params = $_GET;
        $l_url_params[C__GET__NAVMODE] = C__NAVMODE__EDIT;
        unset($l_url_params[C__GET__MAIN_MENU__NAVIGATION_ID], $l_url_params['id']);

        $headers = [
            'id'            => 'ID',
            'object_types'  => 'LC__MODULE__BECON_OC__OBJECT_TYPES',
            'categories'    => 'LC__CMDB__GLOBAL_CATEGORIES',
            'categories_s'  => 'LC__CMDB__SPECIFIC_CATEGORIES',
            'categories_c'  => 'LC__CMDB__CUSTOM_CATEGORIES',
            'hooks'         => 'LC__MODULE__BECON_OC__HOOKS'
        ];

        $configsResult = $configModel->getConfigs();
        $configsCount = count($configsResult);

        $configList = new ComponentList(null, $configsResult);

        $configList->config($headers, '', '[{id}]');

        $configList->set_row_modifier($this);

        if ($configList->createTempTable()) {
            $this->template->assign('list', $configList->getTempTableHtml());
        }

        $editMode = isys_glob_is_edit_mode();

        ComponentNavbar::getInstance()
            ->set_active($isAllowedToEdit, C__NAVBAR_BUTTON__NEW)
            ->set_active($isAllowedToEdit && ($configsCount > 0), C__NAVBAR_BUTTON__EDIT)
            ->set_active($isAllowedToEdit && ($configsCount > 0), C__NAVBAR_BUTTON__DELETE)
            ->set_visible(true, C__NAVBAR_BUTTON__NEW)
            ->set_visible(true, C__NAVBAR_BUTTON__EDIT)
            ->set_visible(true, C__NAVBAR_BUTTON__DELETE);

        $this->template
            ->smarty_tom_add_rule('tom.content.navbar.cRecStatus.p_bInvisible=1')
            ->include_template('contentbottomcontent', ModuleBeconoc::getPath() . 'templates/list.tpl');
    }

    /**
     * @param $p_row
     */
    public function modify_row(&$p_row)
    {
        global $g_dirs;

        $dao = DaoCmdb::instance($this->database);

        if (!empty($p_row['object_types'])) {
            $objTypeIds = explode(",",$p_row['object_types']);
            $object_types = $dao->get_objtype($objTypeIds);
            $objTypeNames = [];
            while ($row = $object_types->get_row()) {
                $objTypeNames[] = $this->language->get($row['isys_obj_type__title']);
            }
            $p_row['object_types'] = implode(", ",$objTypeNames);
        } else {
            $p_row['object_types'] = '<i>'.$this->language->get('LC__MODULE__BECON_OC__ALL_OBJECTTYPES').'</i>';
        }
        if (!empty($p_row['categories'])) {
            $categoryIds = explode(",",$p_row['categories']);
            $categoryNames = [];
            foreach($categoryIds as $categoryId) {
                $catg = $dao->get_all_catg($categoryId)->get_row();
                $categoryNames[] = $this->language->get($catg['isysgui_catg__title']);
            }

            $p_row['categories'] = implode(", ",$categoryNames);
        }

        if (!empty($p_row['categories_s'])) {
            $categoryIds = explode(",",$p_row['categories_s']);
            $categoryNames = [];
            foreach($categoryIds as $categoryId) {
                $cats = $dao->get_all_cats($categoryId)->get_row();
                $categoryNames[] = $this->language->get($cats['isysgui_cats__title']);
            }

            $p_row['categories_s'] = implode(", ",$categoryNames);
        }

        if (!empty($p_row['categories_c'])) {
            $categoryIds = explode(",",$p_row['categories_c']);
            $categoryNames = [];
            foreach($categoryIds as $categoryId) {
                $catc = $dao->get_all_catg_custom($categoryId)->get_row();
                $categoryNames[] = $this->language->get($catc['isysgui_catg_custom__title']);
            }

            $p_row['categories_c'] = implode(", ",$categoryNames);
        }

        $hooks = json_decode($p_row['hooks'],true);

        $p_row['hooks'] = $this->language->get('LC__MODULE__BECON_OC__HOOKS_DEFINED').': '.count($hooks);

    }



}
