<?php

namespace idoit\Module\Beconoc\SettingPage;

/**
 * Class SettingPage
 *
 * @package idoit\Module\Beconoc\SettingPage
 */
abstract class SettingPage implements SettingPageInterface
{
    /**
     * @var \isys_component_template
     */
    protected $template;

    /**
     * @var \isys_component_database
     */
    protected $database;

    /**
     * @var \isys_component_template_language_manager
     */
    protected $language;

    /**
     * SettingPage constructor.
     *
     * @param \isys_component_template                  $template
     * @param \isys_component_database                  $database
     * @param \isys_component_template_language_manager $language
     */
    public function __construct(\isys_component_template $template, \isys_component_database $database, \isys_component_template_language_manager $language)
    {
        $this->template = $template;
        $this->database = $database;
        $this->language = $language;
    }

    /**
     * @param  string $function
     * @param  array  $postData
     *
     * @return array|mixed
     */
    public function processAjax($function, array $postData)
    {
        return [
            'success' => true,
            'data'    => null,
            'message' => null
        ];
    }
}
